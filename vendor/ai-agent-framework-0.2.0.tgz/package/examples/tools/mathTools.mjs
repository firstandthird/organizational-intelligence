import { z } from "zod";

const basicMathSchema = z.object({
  operation: z.enum(["add", "subtract", "multiply", "divide"]),
  a: z.number(),
  b: z.number()
});

const basicMathTool = {
  name: "basic_math",
  description: "Perform basic arithmetic on two numbers.",
  schema: basicMathSchema,
  async run(input) {
    const parsed = basicMathSchema.parse(input);
    const { operation, a, b } = parsed;

    if (operation === "divide" && b === 0) {
      return {
        summary: "Cannot divide by zero.",
        data: {
          operation,
          a,
          b,
          error: "DIVIDE_BY_ZERO"
        }
      };
    }

    const result =
      operation === "add"
        ? a + b
        : operation === "subtract"
          ? a - b
          : operation === "multiply"
            ? a * b
            : a / b;

    return {
      summary: `${a} ${symbolForOperation(operation)} ${b} = ${result}`,
      data: {
        operation,
        a,
        b,
        result
      }
    };
  }
};

const moduleDefinition = {
  name: "example-local-tools",
  tools: [basicMathTool],
  prompts: {
    list() {
      return {
        prompts: [
          {
            name: "math-helper",
            title: "Math Helper",
            description: "Prompt for solving arithmetic with the basic_math tool.",
            arguments: [
              {
                name: "request",
                description: "Calculation request to solve.",
                required: false
              }
            ],
            _meta: {
              tools: ["basic_math"],
              tags: ["math"]
            }
          }
        ]
      };
    },
    get(input) {
      return {
        description: "Prompt for solving arithmetic with the basic_math tool.",
        messages: [
          {
            role: "user",
            content: {
              type: "text",
              text: `Use basic_math to solve: ${input.arguments?.request ?? "the user's calculation"}`
            }
          }
        ]
      };
    }
  }
};

export const name = moduleDefinition.name;
export const tools = moduleDefinition.tools;
export const prompts = moduleDefinition.prompts;

export async function createTools() {
  return moduleDefinition;
}

export default moduleDefinition;

function symbolForOperation(operation) {
  if (operation === "add") {
    return "+";
  }
  if (operation === "subtract") {
    return "-";
  }
  if (operation === "multiply") {
    return "*";
  }
  return "/";
}
