#!/usr/bin/env node
import { createApp } from "./app/app.js";
import { configureRuntime, getRuntimeConfig } from "./app/runtimeConfig.js";
import {
  ensureToolModulesLoaded,
  getAvailableToolNames,
  getLoadedToolModuleNames
} from "./app/toolLoader.js";

interface CliOptions {
  host?: string;
  port?: number;
  projectRoot?: string;
  toolsDir?: string;
  validateOnly: boolean;
}

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  if (args.includes("--help") || args.includes("-h")) {
    printHelp();
    return;
  }

  const options = parseArgs(args);
  configureRuntime({
    host: options.host,
    port: options.port,
    projectRoot: options.projectRoot,
    toolsDir: options.toolsDir
  });

  const runtime = getRuntimeConfig();
  const loaded = await ensureToolModulesLoaded(runtime.toolsDir);

  console.log(`Project root: ${runtime.projectRoot}`);
  console.log(`Tools directory: ${runtime.toolsDir}`);
  console.log(
    `Loaded tool modules (${getLoadedToolModuleNames().length}): ${getLoadedToolModuleNames().join(", ") || "none"}`
  );
  console.log(
    `Loaded MCP skills (${getAvailableToolNames().length}): ${getAvailableToolNames().join(", ") || "none"}`
  );
  console.log(`Slack route: ${runtime.slackRoute} (${runtime.slack.enabled ? "configured" : "not configured"})`);
  console.log(`MCP route: ${runtime.mcpRoute}`);

  if (options.validateOnly) {
    console.log("Runtime validation passed.");
    return;
  }

  const app = createApp(runtime);
  const server = app.listen(runtime.port, runtime.host, () => {
    console.log(
      `${runtime.serverName} listening on ${runtime.host}:${runtime.port} with ${loaded.tools.length} MCP skill${loaded.tools.length === 1 ? "" : "s"}.`
    );
  });

  const shutdown = () => {
    server.close((error) => {
      if (error) {
        console.error("Error closing server:", error);
      }
      process.exit(error ? 1 : 0);
    });
  };

  process.on("SIGINT", shutdown);
  process.on("SIGTERM", shutdown);
}

function parseArgs(args: string[]): CliOptions {
  const options: CliOptions = {
    validateOnly: false
  };

  for (let index = 0; index < args.length; index += 1) {
    const arg = args[index];

    if (arg === "--host") {
      const value = args[index + 1];
      if (!value) {
        throw new Error("Missing value for --host");
      }
      options.host = value;
      index += 1;
      continue;
    }

    if (arg === "--port" || arg === "-p") {
      const value = args[index + 1];
      if (!value) {
        throw new Error("Missing value for --port");
      }
      options.port = Number(value);
      index += 1;
      continue;
    }

    if (arg === "--project-root") {
      const value = args[index + 1];
      if (!value) {
        throw new Error("Missing value for --project-root");
      }
      options.projectRoot = value;
      index += 1;
      continue;
    }

    if (arg === "--tools-dir") {
      const value = args[index + 1];
      if (!value) {
        throw new Error("Missing value for --tools-dir");
      }
      options.toolsDir = value;
      index += 1;
      continue;
    }

    if (arg === "--validate" || arg === "--check") {
      options.validateOnly = true;
      continue;
    }

    throw new Error(`Unknown argument: ${arg}`);
  }

  if (typeof options.port !== "undefined" && (!Number.isFinite(options.port) || options.port <= 0)) {
    throw new Error(`Invalid port: ${options.port}`);
  }

  return options;
}

function printHelp(): void {
  console.log(
    [
      "AI Agent Framework",
      "",
      "Usage:",
      "  ai-agent-framework",
      "  ai-agent-framework --validate",
      "",
      "Options:",
      "  --host <value>            Override MCP_HOST",
      "  --port, -p <number>       Override MCP_PORT / PORT",
      "  --project-root <path>     Resolve tools and .env files from a different host root",
      "  --tools-dir <path>        Override the host tools directory",
      "  --validate, --check       Validate tool loading then exit",
      "  --help, -h                Show this message",
      "",
      "Environment:",
      "  MCP_HOST, MCP_PORT, PORT, MCP_ROUTE, HEALTH_ROUTE, SLACK_ROUTE",
      "  MCP_AUTH_BEARER_TOKEN, MCP_SERVER_NAME, MCP_SERVER_VERSION",
      "  SLACK_SIGNING_SECRET, SLACK_BOT_TOKEN, TOOLS_DIR, OPENAI_API_KEY, MCP_PROXY_SERVERS"
    ].join("\n")
  );
}

main().catch((error) => {
  console.error("CLI error:", error);
  process.exit(1);
});
