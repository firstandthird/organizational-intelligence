import { describe, expect, it, vi } from "vitest";
import { loadMcpProxyToolDefinitions } from "../app/mcpProxyTools.js";

describe("loadMcpProxyToolDefinitions", () => {
  it("returns an empty array when there are no servers", async () => {
    await expect(loadMcpProxyToolDefinitions([])).resolves.toEqual([]);
  });

  it("skips unreachable servers and still resolves", async () => {
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    const tools = await loadMcpProxyToolDefinitions([
      { url: "http://127.0.0.1:1/mcp" }
    ]);
    expect(tools).toEqual([]);
    expect(warn).toHaveBeenCalled();
    expect(String(warn.mock.calls[0]?.[0])).toMatch(/\[MCP proxy\] Skipping/);
    warn.mockRestore();
  });

  it("skips invalid URLs", async () => {
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    const tools = await loadMcpProxyToolDefinitions([{ url: "not-a-url" }]);
    expect(tools).toEqual([]);
    expect(warn).toHaveBeenCalled();
    expect(String(warn.mock.calls[0]?.[0])).toMatch(/invalid url/);
    warn.mockRestore();
  });
});
