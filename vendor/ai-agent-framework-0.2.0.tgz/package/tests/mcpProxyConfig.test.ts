import { describe, expect, it } from "vitest";
import { parseMcpProxyServersFromEnv } from "../app/runtimeConfig.js";

describe("parseMcpProxyServersFromEnv", () => {
  it("returns an empty array when the value is omitted or blank", () => {
    expect(parseMcpProxyServersFromEnv(undefined)).toEqual([]);
    expect(parseMcpProxyServersFromEnv("")).toEqual([]);
    expect(parseMcpProxyServersFromEnv("   ")).toEqual([]);
  });

  it("parses url-only entries", () => {
    expect(
      parseMcpProxyServersFromEnv(
        JSON.stringify([{ url: "http://127.0.0.1:3000/mcp" }])
      )
    ).toEqual([{ url: "http://127.0.0.1:3000/mcp", authorization: undefined }]);
  });

  it("maps bearerToken and token to Authorization Bearer", () => {
    expect(
      parseMcpProxyServersFromEnv(
        JSON.stringify([{ url: "http://a/mcp", bearerToken: "secret" }])
      )
    ).toEqual([{ url: "http://a/mcp", authorization: "Bearer secret" }]);
    expect(
      parseMcpProxyServersFromEnv(JSON.stringify([{ url: "http://b/mcp", token: "t" }]))
    ).toEqual([{ url: "http://b/mcp", authorization: "Bearer t" }]);
  });

  it("prefers explicit authorization over bearerToken", () => {
    expect(
      parseMcpProxyServersFromEnv(
        JSON.stringify([
          {
            url: "http://c/mcp",
            authorization: "Basic x",
            bearerToken: "ignored"
          }
        ])
      )
    ).toEqual([{ url: "http://c/mcp", authorization: "Basic x" }]);
  });

  it("rejects invalid JSON", () => {
    expect(() => parseMcpProxyServersFromEnv("not json")).toThrow(/valid JSON/);
  });

  it("rejects non-array JSON", () => {
    expect(() => parseMcpProxyServersFromEnv("{}")).toThrow();
  });

  it("rejects entries missing url", () => {
    expect(() => parseMcpProxyServersFromEnv(JSON.stringify([{}]))).toThrow();
  });

  it("rejects unknown keys (strict schema)", () => {
    expect(() =>
      parseMcpProxyServersFromEnv(
        JSON.stringify([{ url: "http://x/mcp", extra: 1 }])
      )
    ).toThrow();
  });
});
