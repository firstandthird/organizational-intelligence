import { describe, expect, it } from "vitest";
import {
  addSlackReaction,
  deleteSlackMessage,
  postThreadReply,
  updateSlackMessage,
  type SlackMessagingClient,
  uploadSlackTextSnippet
} from "../app/slackMessaging.js";

interface CallLog {
  postMessage: Record<string, unknown>[];
  update: Record<string, unknown>[];
  delete: Record<string, unknown>[];
  startStream: Record<string, unknown>[];
  appendStream: Record<string, unknown>[];
  stopStream: Record<string, unknown>[];
  uploadV2: Record<string, unknown>[];
  reactionsAdd: Record<string, unknown>[];
  apiCall: Array<{ method: string; args: Record<string, unknown> | undefined }>;
}

function createFakeClient(options: {
  startStreamError?: Error;
  useApiCallOnly?: boolean;
} = {}): {
  client: SlackMessagingClient;
  calls: CallLog;
} {
  const calls: CallLog = {
    postMessage: [],
    update: [],
    delete: [],
    startStream: [],
    appendStream: [],
    stopStream: [],
    uploadV2: [],
    reactionsAdd: [],
    apiCall: []
  };

  const chat: SlackMessagingClient["chat"] = {
    postMessage: async (args) => {
      calls.postMessage.push(args);
      return { ts: "posted-ts" };
    }
  };

  if (!options.useApiCallOnly) {
    chat.update = async (args) => {
      calls.update.push(args);
      return {};
    };
    chat.delete = async (args) => {
      calls.delete.push(args);
      return {};
    };
    chat.startStream = async (args) => {
      calls.startStream.push(args);
      if (options.startStreamError) {
        throw options.startStreamError;
      }
      return { ts: "stream-ts" };
    };
    chat.appendStream = async (args) => {
      calls.appendStream.push(args);
    };
    chat.stopStream = async (args) => {
      calls.stopStream.push(args);
    };
  }

  const client: SlackMessagingClient = {
    chat
  };

  if (!options.useApiCallOnly) {
    client.files = {
      uploadV2: async (args) => {
        calls.uploadV2.push(args);
        return {};
      }
    };
    client.reactions = {
      add: async (args) => {
        calls.reactionsAdd.push(args);
        return {};
      }
    };
  }

  if (options.useApiCallOnly) {
    client.apiCall = async (method, args) => {
      calls.apiCall.push({ method, args });

      if (method === "chat.startStream") {
        if (options.startStreamError) {
          throw options.startStreamError;
        }
        return { ts: "stream-ts" };
      }

      return {};
    };
  }

  return { client, calls };
}

describe("slackMessaging", () => {
  it("posts a normal threaded reply when mode is normal", async () => {
    const { client, calls } = createFakeClient();

    await postThreadReply(client, "C123", "111.222", "Hello there", {
      mode: "normal"
    });

    expect(calls.postMessage).toHaveLength(1);
    expect(calls.startStream).toHaveLength(0);
    expect(calls.postMessage[0]).toMatchObject({
      channel: "C123",
      thread_ts: "111.222",
      text: "Hello there",
      mrkdwn: true
    });
  });

  it("streams threaded replies when mode is stream", async () => {
    const { client, calls } = createFakeClient();

    await postThreadReply(client, "C123", "111.222", "0123456789ABCDEF", {
      mode: "stream",
      recipientUserId: "U123",
      recipientTeamId: "T123",
      streamChunkSize: 5
    });

    expect(calls.postMessage).toHaveLength(0);
    expect(calls.startStream).toHaveLength(1);
    expect(calls.appendStream).toHaveLength(3);
    expect(calls.stopStream).toHaveLength(1);
    expect(calls.startStream[0]).toMatchObject({
      channel: "C123",
      thread_ts: "111.222",
      markdown_text: "01234",
      recipient_user_id: "U123",
      recipient_team_id: "T123"
    });
    expect(calls.stopStream[0]?.ts).toBe("stream-ts");
  });

  it("falls back to postMessage when stream start fails", async () => {
    const { client, calls } = createFakeClient({
      startStreamError: new Error("stream failed")
    });

    await postThreadReply(client, "C123", "111.222", "Fallback message", {
      mode: "stream"
    });

    expect(calls.startStream).toHaveLength(1);
    expect(calls.postMessage).toHaveLength(1);
    expect(calls.postMessage[0]?.text).toBe("Fallback message");
  });

  it("streams via apiCall when chat stream methods are unavailable", async () => {
    const { client, calls } = createFakeClient({ useApiCallOnly: true });

    await postThreadReply(client, "C123", "111.222", "0123456789ABCDEF", {
      mode: "stream",
      recipientUserId: "U123",
      recipientTeamId: "T123",
      streamChunkSize: 5
    });

    expect(calls.apiCall).toHaveLength(5);
    expect(calls.apiCall[0]).toMatchObject({
      method: "chat.startStream",
      args: {
        channel: "C123",
        thread_ts: "111.222",
        markdown_text: "01234",
        recipient_user_id: "U123",
        recipient_team_id: "T123"
      }
    });
    expect(calls.apiCall[4]).toMatchObject({
      method: "chat.stopStream",
      args: {
        channel: "C123",
        ts: "stream-ts"
      }
    });
  });

  it("uploads a text snippet via files.uploadV2 when available", async () => {
    const { client, calls } = createFakeClient();

    await uploadSlackTextSnippet(client, {
      channelId: "C123",
      threadTs: "111.222",
      filename: "previous-output.txt",
      content: "example output",
      title: "Previous output"
    });

    expect(calls.uploadV2).toHaveLength(1);
    expect(calls.uploadV2[0]).toMatchObject({
      channel_id: "C123",
      thread_ts: "111.222",
      filename: "previous-output.txt",
      content: "example output",
      title: "Previous output",
      filetype: "text"
    });
  });

  it("adds a Slack reaction and ignores already_reacted errors", async () => {
    const { client, calls } = createFakeClient();

    await addSlackReaction(client, {
      channel: "C123",
      timestamp: "111.222",
      name: "eyes"
    });

    expect(calls.reactionsAdd).toHaveLength(1);

    const alreadyReactedClient: SlackMessagingClient = {
      chat: {
        postMessage: async () => ({ ts: "posted-ts" })
      },
      reactions: {
        add: async () => {
          throw {
            data: {
              error: "already_reacted"
            }
          };
        }
      }
    };

    await expect(
      addSlackReaction(alreadyReactedClient, {
        channel: "C123",
        timestamp: "111.222",
        name: "eyes"
      })
    ).resolves.toBeUndefined();
  });

  it("updates and deletes messages using the available Slack APIs", async () => {
    const { client, calls } = createFakeClient();
    const apiFallback = createFakeClient({ useApiCallOnly: true });

    await updateSlackMessage(client, {
      channel: "C123",
      ts: "111.222",
      text: "Rewritten message"
    });
    await deleteSlackMessage(apiFallback.client, {
      channel: "C123",
      ts: "111.222"
    });

    expect(calls.update).toHaveLength(1);
    expect(calls.update[0]).toMatchObject({
      channel: "C123",
      ts: "111.222",
      text: "Rewritten message",
      mrkdwn: true
    });
    expect(apiFallback.calls.apiCall[0]).toMatchObject({
      method: "chat.delete",
      args: {
        channel: "C123",
        ts: "111.222"
      }
    });
  });
});
