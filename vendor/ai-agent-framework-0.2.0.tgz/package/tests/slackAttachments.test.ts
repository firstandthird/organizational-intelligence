import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  buildAttachmentContextForSlackMessage,
  hasSlackFiles
} from "../app/slackAttachments.js";
import { configureRuntime } from "../app/runtimeConfig.js";

describe("slackAttachments", () => {
  const originalFetch = globalThis.fetch;
  const originalToken = process.env.SLACK_BOT_TOKEN;

  beforeEach(() => {
    configureRuntime({
      projectRoot: process.cwd(),
      toolsDir: "./examples/tools",
      slackAttachments: {
        enabled: true,
        maxFileBytes: 2_000_000,
        maxCharsPerFile: 50_000,
        maxFilesPerMessage: 8
      }
    });
    process.env.SLACK_BOT_TOKEN = "xoxb-test-token";
  });

  afterEach(() => {
    globalThis.fetch = originalFetch;
    if (typeof originalToken === "string") {
      process.env.SLACK_BOT_TOKEN = originalToken;
    } else {
      delete process.env.SLACK_BOT_TOKEN;
    }
  });

  it("detects when a Slack event includes files", () => {
    expect(hasSlackFiles({ files: [{ name: "notes.txt" }] })).toBe(true);
    expect(hasSlackFiles({ files: [] })).toBe(false);
    expect(hasSlackFiles({})).toBe(false);
  });

  it("includes text attachment contents in the generated context", async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      new Response("Quarterly notes\nLine two", {
        status: 200
      })
    );
    globalThis.fetch = fetchMock as typeof fetch;

    const context = await buildAttachmentContextForSlackMessage({
      ts: "111.222",
      files: [
        {
          name: "notes.txt",
          size: 24,
          url_private: "https://files.example.test/notes.txt"
        }
      ]
    });

    expect(context).toContain("Slack attachments from message 111.222:");
    expect(context).toContain("[attachment included: notes.txt (24 bytes)]");
    expect(context).toContain("Quarterly notes");
    expect(fetchMock).toHaveBeenCalledWith("https://files.example.test/notes.txt", {
      headers: {
        Authorization: "Bearer xoxb-test-token"
      },
      signal: expect.any(AbortSignal)
    });
  });

  it("skips unsupported attachment types", async () => {
    const fetchMock = vi.fn();
    globalThis.fetch = fetchMock as typeof fetch;

    const context = await buildAttachmentContextForSlackMessage({
      files: [
        {
          name: "diagram.png",
          size: 128,
          url_private: "https://files.example.test/diagram.png"
        }
      ]
    });

    expect(context).toContain("[attachment skipped: diagram.png (unsupported type (.png))]");
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("respects maxFilesPerMessage and records skipped overflow files", async () => {
    configureRuntime({
      projectRoot: process.cwd(),
      toolsDir: "./examples/tools",
      slackAttachments: {
        enabled: true,
        maxFileBytes: 2_000_000,
        maxCharsPerFile: 50_000,
        maxFilesPerMessage: 1
      }
    });

    const fetchMock = vi
      .fn()
      .mockResolvedValue(new Response("first attachment", { status: 200 }));
    globalThis.fetch = fetchMock as typeof fetch;

    const context = await buildAttachmentContextForSlackMessage({
      files: [
        {
          name: "first.txt",
          size: 16,
          url_private: "https://files.example.test/first.txt"
        },
        {
          name: "second.txt",
          size: 17,
          url_private: "https://files.example.test/second.txt"
        }
      ]
    });

    expect(fetchMock).toHaveBeenCalledTimes(1);
    expect(context).toContain("[attachment included: first.txt (16 bytes)]");
    expect(context).toContain(
      "[attachment skipped: 1 additional file (exceeds max_files_per_message (1))]"
    );
  });

  it("returns null when attachment ingestion is disabled", async () => {
    configureRuntime({
      projectRoot: process.cwd(),
      toolsDir: "./examples/tools",
      slackAttachments: {
        enabled: false
      }
    });

    const fetchMock = vi.fn();
    globalThis.fetch = fetchMock as typeof fetch;

    const context = await buildAttachmentContextForSlackMessage({
      files: [
        {
          name: "notes.txt",
          size: 12,
          url_private: "https://files.example.test/notes.txt"
        }
      ]
    });

    expect(context).toBeNull();
    expect(fetchMock).not.toHaveBeenCalled();
  });
});
