import { describe, expect, it } from "vitest";
import { existsSync, mkdirSync, mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
// @ts-expect-error deploy script is plain JS in scripts/
import {
  buildEnvValues,
  createDeployablePackageJson,
  createDockerfile,
  createStagingDirectory
} from "../scripts/deploy.js";

describe("deploy script helpers", () => {
  it("writes a canonical runtime start script for staged host packages", () => {
    const generated = createDeployablePackageJson({
      name: "host-project",
      version: "1.0.0",
      dependencies: {
        "ai-agent-framework": "^0.2.0"
      },
      scripts: {
        test: "vitest"
      }
    });

    expect(generated.scripts.start).toBe("node ./node_modules/ai-agent-framework/dist/cli.js");
    expect(generated.scripts["mcp:validate"]).toBe(
      "node ./node_modules/ai-agent-framework/dist/cli.js --validate"
    );
  });

  it("fails fast when the host package does not depend on the runtime", () => {
    expect(() =>
      createDeployablePackageJson({
        name: "host-project",
        version: "1.0.0",
        dependencies: {}
      })
    ).toThrow("Host package.json must declare ai-agent-framework");
  });

  it("builds the Cloud Run env payload", () => {
    const previousRepositoryFolder = process.env.REPOSITORY_FOLDER;
    process.env.REPOSITORY_FOLDER = "../repository-assets";

    const values = buildEnvValues("host-project");

    try {
      expect(values.MCP_HOST).toBeDefined();
      expect(values.MCP_ROUTE).toBeDefined();
      expect(values.HEALTH_ROUTE).toBeDefined();
      expect(values.MCP_SERVER_NAME).toBe("host-project");
      expect(values.REPOSITORY_FOLDER).toBe("../repository-assets");
    } finally {
      if (previousRepositoryFolder === undefined) {
        delete process.env.REPOSITORY_FOLDER;
      } else {
        process.env.REPOSITORY_FOLDER = previousRepositoryFolder;
      }
    }
  });

  it("omits absent optional lockfiles from the generated Dockerfile", () => {
    const dockerfile = createDockerfile({
      hasPackageLock: true,
      hasPnpmLock: false,
      hasNpmShrinkwrap: false
    });

    expect(dockerfile).toContain("COPY package-lock.json ./");
    expect(dockerfile).not.toContain("COPY pnpm-lock.yaml ./");
    expect(dockerfile).not.toContain("COPY npm-shrinkwrap.json ./");
    expect(dockerfile).toContain(
      "elif [ -f package-lock.json ] || [ -f npm-shrinkwrap.json ]; then npm ci;"
    );
  });

  it("copies local file dependencies before install", () => {
    const dockerfile = createDockerfile({
      hasPackageLock: true,
      localDependencyPaths: ["vendor/ai-agent-framework-0.2.0.tgz"]
    });

    expect(dockerfile).toContain(
      'COPY ["vendor/ai-agent-framework-0.2.0.tgz", "./vendor/"]'
    );
  });

  it("copies REPOSITORY_FOLDER from the host .env into the staged app context", () => {
    const tempRoot = mkdtempSync(path.join(tmpdir(), "deploy-script-test-"));
    const hostRoot = path.join(tempRoot, "host");
    const repositoryRoot = path.join(tempRoot, "repository-assets");
    mkdirSync(hostRoot, { recursive: true });
    mkdirSync(path.join(repositoryRoot, "nested"), { recursive: true });
    writeFileSync(path.join(hostRoot, ".env"), "REPOSITORY_FOLDER=../repository-assets\n", "utf8");
    writeFileSync(path.join(hostRoot, "index.js"), "export {};\n", "utf8");
    writeFileSync(path.join(repositoryRoot, "nested", "README.txt"), "payload\n", "utf8");

    const previousRepositoryFolder = process.env.REPOSITORY_FOLDER;
    delete process.env.REPOSITORY_FOLDER;

    try {
      const stage = createStagingDirectory(hostRoot, {
        name: "host-project",
        private: true
      });

      try {
        expect(
          existsSync(path.join(stage.stageDir, "repository-assets", "nested", "README.txt"))
        ).toBe(true);
      } finally {
        stage.cleanup();
      }
    } finally {
      if (previousRepositoryFolder === undefined) {
        delete process.env.REPOSITORY_FOLDER;
      } else {
        process.env.REPOSITORY_FOLDER = previousRepositoryFolder;
      }
      rmSync(tempRoot, { recursive: true, force: true });
    }
  });
});
