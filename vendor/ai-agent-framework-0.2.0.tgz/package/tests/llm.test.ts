import { AIMessage } from "@langchain/core/messages";
import { beforeEach, describe, expect, it, vi } from "vitest";
import * as z from "zod/v4";
import { runSlackLlmTurn } from "../app/llm.js";
import { configureRuntime } from "../app/runtimeConfig.js";
import type { LLMProvider } from "../types/llm.js";
import type { LoadedToolDefinition } from "../types/tool.js";

describe("runSlackLlmTurn", () => {
  beforeEach(() => {
    configureRuntime({
      projectRoot: process.cwd(),
      toolsDir: "./examples/tools",
      mcpProxyServers: [],
      serverName: "test-host",
      serverVersion: "1.0.0"
    });
  });

  it("returns a direct LLM response when no tool calls are requested", async () => {
    const generate = vi.fn().mockResolvedValue({
      message: new AIMessage("Slack-ready answer"),
      toolCalls: []
    });
    const provider: LLMProvider = {
      generate,
      stream: async function* () {}
    };

    const result = await runSlackLlmTurn(
      {
        text: "What can you do?",
        channelId: "C123",
        threadTs: "1000.000",
        userId: "U123"
      },
      {
        getProvider: () => provider,
        loadTools: async () => ({ tools: [] })
      }
    );

    expect(result.text).toBe("Slack-ready answer");
    expect(result.toolCallCount).toBe(0);
    expect(generate).toHaveBeenCalledTimes(1);
  });

  it("includes attachment context in the user prompt", async () => {
    const generate = vi.fn().mockResolvedValue({
      message: new AIMessage("Done."),
      toolCalls: []
    });
    const provider: LLMProvider = {
      generate,
      stream: async function* () {}
    };

    await runSlackLlmTurn(
      {
        text: "Please summarize this.",
        attachmentContext: "Slack attachments from message 1000.000:\n\n[attachment included: notes.txt (12 bytes)]\nHello from Slack",
        channelId: "C123",
        threadTs: "1000.000",
        userId: "U123"
      },
      {
        getProvider: () => provider,
        loadTools: async () => ({ tools: [] })
      }
    );

    const firstCall = generate.mock.calls[0]?.[0];
    const humanMessage = firstCall?.messages?.[1];
    expect(humanMessage?.content).toContain("Please summarize this.");
    expect(humanMessage?.content).toContain("attachment included: notes.txt");
  });

  it("executes local tools and returns the follow-up LLM response", async () => {
    const execute = vi.fn().mockResolvedValue({
      summary: "2 + 3 = 5",
      data: {
        result: 5
      }
    });
    const tool: LoadedToolDefinition = {
      name: "basic_math",
      description: "Performs simple arithmetic.",
      inputSchema: z.object({
        operation: z.enum(["add"]),
        a: z.number(),
        b: z.number()
      }),
      execute,
      moduleName: "test-tools",
      sourcePath: "/virtual/basic_math.mjs"
    };
    const provider: LLMProvider = {
      generate: vi
        .fn()
        .mockResolvedValueOnce({
          message: new AIMessage({
            content: "",
            tool_calls: [
              {
                id: "call_1",
                name: "basic_math",
                args: {
                  operation: "add",
                  a: 2,
                  b: 3
                }
              }
            ]
          }),
          toolCalls: [
            {
              id: "call_1",
              name: "basic_math",
              args: {
                operation: "add",
                a: 2,
                b: 3
              }
            }
          ]
        })
        .mockResolvedValueOnce({
          message: new AIMessage("The result is 5."),
          toolCalls: []
        }),
      stream: async function* () {}
    };

    const result = await runSlackLlmTurn(
      {
        text: "Add 2 and 3",
        channelId: "C123",
        threadTs: "1000.000",
        userId: "U123"
      },
      {
        getProvider: () => provider,
        loadTools: async () => ({ tools: [tool] })
      }
    );

    expect(result.text).toBe("The result is 5.");
    expect(result.toolCallCount).toBe(1);
    expect(execute).toHaveBeenCalledWith(
      {
        operation: "add",
        a: 2,
        b: 3
      },
      {
        request: {
          requestId: expect.stringContaining("basic_math:"),
          transport: "slack"
        },
        slack: {
          channelId: "C123",
          threadTs: "1000.000",
          userId: "U123"
        }
      }
    );
    expect(provider.generate).toHaveBeenCalledTimes(2);
  });
});
