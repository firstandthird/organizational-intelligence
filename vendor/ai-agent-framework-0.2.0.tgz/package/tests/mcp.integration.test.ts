import request from "supertest";
import { beforeEach, describe, expect, it } from "vitest";
import { createApp } from "../app/app.js";
import { configureRuntime, getRuntimeConfig } from "../app/runtimeConfig.js";
import { resetToolModuleCache } from "../app/toolLoader.js";

describe("MCP integration", () => {
  beforeEach(() => {
    resetToolModuleCache();
    configureRuntime({
      projectRoot: process.cwd(),
      toolsDir: "./examples/tools",
      mcpProxyServers: [],
      authBearerToken: "test-token",
      serverName: "test-host",
      serverVersion: "1.0.0"
    });
  });

  it("lists skills discovered from the host tools directory", async () => {
    const app = createApp(getRuntimeConfig());

    const response = await request(app)
      .post("/mcp")
      .set("Authorization", "Bearer test-token")
      .set("Accept", "application/json, text/event-stream")
      .send({
        jsonrpc: "2.0",
        id: 1,
        method: "tools/list",
        params: {}
      });

    expect(response.status).toBe(200);
    const toolNames = response.body.result?.tools?.map((tool: { name: string }) => tool.name) ?? [];
    expect(toolNames).toContain("basic_math");
  });

  it("calls a loaded skill and returns structured content", async () => {
    const app = createApp(getRuntimeConfig());

    const response = await request(app)
      .post("/mcp")
      .set("Authorization", "Bearer test-token")
      .set("Accept", "application/json, text/event-stream")
      .send({
        jsonrpc: "2.0",
        id: 2,
        method: "tools/call",
        params: {
          name: "basic_math",
          arguments: {
            operation: "add",
            a: 2,
            b: 3
          }
        }
      });

    expect(response.status).toBe(200);
    expect(response.body.result?.isError).not.toBe(true);
    expect(response.body.result?.structuredContent?.data?.result).toBe(5);
  });

  it("lists prompts discovered from host tool modules", async () => {
    const app = createApp(getRuntimeConfig());

    const response = await request(app)
      .post("/mcp")
      .set("Authorization", "Bearer test-token")
      .set("Accept", "application/json, text/event-stream")
      .send({
        jsonrpc: "2.0",
        id: 4,
        method: "prompts/list",
        params: {}
      });

    expect(response.status).toBe(200);
    const prompts = response.body.result?.prompts ?? [];
    expect(prompts).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          name: "math-helper",
          title: "Math Helper",
          description: "Prompt for solving arithmetic with the basic_math tool."
        })
      ])
    );
  });

  it("gets prompts discovered from host tool modules", async () => {
    const app = createApp(getRuntimeConfig());

    const response = await request(app)
      .post("/mcp")
      .set("Authorization", "Bearer test-token")
      .set("Accept", "application/json, text/event-stream")
      .send({
        jsonrpc: "2.0",
        id: 5,
        method: "prompts/get",
        params: {
          name: "math-helper",
          arguments: {
            request: "2 + 3"
          }
        }
      });

    expect(response.status).toBe(200);
    expect(response.body.result?.messages?.[0]?.role).toBe("user");
    expect(response.body.result?.messages?.[0]?.content?.text).toContain("2 + 3");
  });

  it("rejects unauthorized MCP requests when a bearer token is configured", async () => {
    const app = createApp(getRuntimeConfig());

    const response = await request(app).post("/mcp").send({
      jsonrpc: "2.0",
      id: 3,
      method: "tools/list",
      params: {}
    });

    expect(response.status).toBe(401);
    expect(response.body.error).toBe("Unauthorized");
  });
});
