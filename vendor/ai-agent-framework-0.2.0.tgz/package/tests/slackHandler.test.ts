import request from "supertest";
import { beforeEach, describe, expect, it } from "vitest";
import { createApp } from "../app/app.js";
import { configureRuntime, getRuntimeConfig } from "../app/runtimeConfig.js";
import { resetSlackRuntime } from "../app/slackHandler.js";
import { resetToolModuleCache } from "../app/toolLoader.js";

describe("Slack handler route", () => {
  beforeEach(() => {
    resetSlackRuntime();
    resetToolModuleCache();
    configureRuntime({
      projectRoot: process.cwd(),
      toolsDir: "./examples/tools",
      mcpProxyServers: [],
      authBearerToken: undefined,
      serverName: "test-host"
    });
  });

  it("is served from express even when Slack credentials are missing", async () => {
    const app = createApp(getRuntimeConfig());

    const response = await request(app).post("/api/slack").send({});

    expect(response.status).toBe(503);
    expect(response.body.error).toContain("Slack is not configured");
  });
});
