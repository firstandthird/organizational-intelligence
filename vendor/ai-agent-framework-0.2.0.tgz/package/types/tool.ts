import type { z } from "zod/v4";
import type { GetPromptRequestParams, GetPromptResult, ListPromptsResult } from "@modelcontextprotocol/sdk/types.js";

export interface ToolExecutionContext {
  request: {
    requestId: string;
    sessionId?: string;
    transport: "mcp" | "slack";
  };
  slack?: {
    channelId: string;
    threadTs: string;
    userId?: string;
  };
}

export type ToolResult = string | Record<string, unknown> | null | undefined;

export interface ExternalToolDefinition {
  name: string;
  title?: string;
  description: string;
  inputSchema?: z.ZodTypeAny;
  outputSchema?: z.ZodTypeAny;
  schema?: z.ZodTypeAny;
  execute?: (input: Record<string, unknown>, ctx: ToolExecutionContext) => Promise<ToolResult> | ToolResult;
  run?: (input: Record<string, unknown>, ctx: ToolExecutionContext) => Promise<ToolResult> | ToolResult;
}

export interface ExternalToolModule {
  name: string;
  tools?: ExternalToolDefinition[];
  prompts?: ExternalPromptProvider;
}

export interface ExternalToolModuleFactory {
  name?: string;
  createTools?: () => Promise<ExternalToolModule> | ExternalToolModule;
  tools?: ExternalToolDefinition[];
  prompts?: ExternalPromptProvider;
}

export interface LoadedToolDefinition {
  name: string;
  title?: string;
  description: string;
  inputSchema: z.ZodTypeAny;
  outputSchema?: z.ZodTypeAny;
  execute: NonNullable<ExternalToolDefinition["execute"] | ExternalToolDefinition["run"]>;
  moduleName: string;
  sourcePath: string;
}

export interface ExternalPromptProvider {
  list: (input?: { cursor?: string }) => Promise<ListPromptsResult> | ListPromptsResult;
  get: (input: GetPromptRequestParams) => Promise<GetPromptResult> | GetPromptResult;
}

export interface LoadedPromptProvider extends ExternalPromptProvider {
  moduleName: string;
  sourcePath: string;
}
