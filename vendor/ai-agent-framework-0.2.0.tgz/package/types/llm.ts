import type { BaseMessage } from "@langchain/core/messages";
import type { DynamicStructuredTool } from "@langchain/core/tools";
import type { AIMessage } from "@langchain/core/messages";

export interface ToolCall {
  id: string;
  name: string;
  args: Record<string, unknown>;
}

export interface LLMGenerateOptions {
  model: string;
  messages: BaseMessage[];
  tools?: DynamicStructuredTool[];
  temperature?: number;
  maxTokens?: number;
}

export interface LLMGenerateResult {
  message: AIMessage;
  toolCalls: ToolCall[];
}

export interface LLMStreamOptions {
  model: string;
  messages: BaseMessage[];
  tools?: DynamicStructuredTool[];
  temperature?: number;
  maxTokens?: number;
}

export interface LLMProvider {
  generate(options: LLMGenerateOptions): Promise<LLMGenerateResult>;
  stream(options: LLMStreamOptions): AsyncGenerator<string>;
}