import { DynamicStructuredTool } from "@langchain/core/tools";
import { z } from "zod";
import { getInternalTools, INTERNAL_TOOL_MODULE_NAME } from "./internal/index.js";
import type { ExternalToolDefinition, ToolContext } from "../types/tool.js";
import { logToolDebugEvent } from "../app/logSink.js";
import { isOAuthServiceResolutionError } from "../app/oauth.js";

interface ToolModule {
  name: string;
  tools: ExternalToolDefinition[];
}

const toolRegistry = new Map<string, ExternalToolDefinition>();
let loadedModuleNames: string[] = [];
let loaded = false;

export async function ensureToolModulesLoaded(): Promise<void> {
  if (loaded) {
    return;
  }

  toolRegistry.clear();
  loadedModuleNames = [INTERNAL_TOOL_MODULE_NAME];

  registerToolDefinitions(
    {
      name: INTERNAL_TOOL_MODULE_NAME,
      tools: getInternalTools()
    }
  );
  loaded = true;
}

export async function instantiateTools(
  toolNames: string[],
  ctx: ToolContext
): Promise<DynamicStructuredTool[]> {
  await ensureToolModulesLoaded();

  return toolNames.map((toolName) => {
    const tool = toolRegistry.get(toolName);
    if (!tool) {
      throw new Error(`Tool not registered: ${toolName}`);
    }

    return createDynamicTool(tool, ctx);
  });
}

export function getAvailableToolNames(): string[] {
  return Array.from(toolRegistry.keys()).sort();
}

export function getLoadedToolModuleNames(): string[] {
  return [...loadedModuleNames];
}

export function createDynamicTool(tool: ExternalToolDefinition, ctx: ToolContext): DynamicStructuredTool {
  return new DynamicStructuredTool({
    name: tool.name,
    description: tool.description,
    schema: tool.schema ?? z.object({}).passthrough(),
    func: async (input) => {
      const payload = (input ?? {}) as Record<string, unknown>;
      const startedAt = Date.now();

      logToolDebugEvent("tool_started", {
        toolName: tool.name,
        args: payload
      });

      try {
        if (tool.isDestructive?.(payload)) {
          if (!ctx.requestConfirmation) {
            const result = {
              summary: `Destructive action requested in tool ${tool.name}, but no confirmation handler is configured.`
            };
            logToolDebugEvent("tool_finished", {
              toolName: tool.name,
              args: payload,
              result,
              durationMs: Date.now() - startedAt
            });
            return JSON.stringify(result);
          }

          const approved = await ctx.requestConfirmation(
            `Confirm destructive action for tool ${tool.name}?`
          );
          if (!approved) {
            const result = { summary: "Destructive action was not confirmed." };
            logToolDebugEvent("tool_finished", {
              toolName: tool.name,
              args: payload,
              result,
              durationMs: Date.now() - startedAt
            });
            return JSON.stringify(result);
          }
        }

        const result = await tool.run(payload, ctx);
        logToolDebugEvent("tool_finished", {
          toolName: tool.name,
          args: payload,
          result,
          durationMs: Date.now() - startedAt
        });
        return JSON.stringify(result);
      } catch (error) {
        if (isOAuthServiceResolutionError(error)) {
          const result = {
            summary: error.message,
            data: {
              error_type: error.code,
              recoverable: true
            }
          };
          logToolDebugEvent("tool_finished", {
            toolName: tool.name,
            args: payload,
            result,
            durationMs: Date.now() - startedAt
          });
          return JSON.stringify(result);
        }

        logToolDebugEvent("tool_failed", {
          toolName: tool.name,
          args: payload,
          durationMs: Date.now() - startedAt,
          error
        });
        throw error;
      }
    }
  });
}

function validateToolDefinition(tool: ExternalToolDefinition, moduleName: string): void {
  if (!tool.name || typeof tool.name !== "string") {
    throw new Error(`Tool module ${moduleName} has a tool with invalid name.`);
  }

  if (!tool.description || typeof tool.description !== "string") {
    throw new Error(`Tool ${tool.name} from module ${moduleName} is missing description.`);
  }

  if (!tool.schema || typeof (tool.schema as { safeParse?: unknown }).safeParse !== "function") {
    throw new Error(`Tool ${tool.name} from module ${moduleName} must provide a Zod schema.`);
  }

  if (typeof tool.run !== "function") {
    throw new Error(`Tool ${tool.name} from module ${moduleName} must provide run(input, ctx).`);
  }
}

function registerToolDefinitions(module: ToolModule): void {
  for (const tool of module.tools) {
    if (toolRegistry.has(tool.name)) {
      throw new Error(`Duplicate tool name detected: ${tool.name}`);
    }

    validateToolDefinition(tool, module.name);
    toolRegistry.set(tool.name, tool);
  }
}
