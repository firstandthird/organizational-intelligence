import { existsSync, readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import * as z from "zod/v4";

export interface McpProxyServerConfig {
  /** Streamable HTTP MCP endpoint (e.g. https://host/mcp). */
  url: string;
  /**
   * Optional `Authorization` header value for outbound requests (e.g. `Bearer <token>`).
   * Set via JSON `authorization`, or `bearerToken` / `token` (both become `Bearer …`).
   */
  authorization?: string;
}

export interface RuntimeConfig {
  projectRoot: string;
  toolsDir: string;
  host: string;
  port: number;
  mcpRoute: string;
  healthRoute: string;
  slackRoute: string;
  authBearerToken?: string;
  serverName: string;
  serverVersion: string;
  /** Remote MCP servers whose tools are merged with host ./tools after local modules load. */
  mcpProxyServers: McpProxyServerConfig[];
  slack: {
    signingSecret?: string;
    botToken?: string;
    enabled: boolean;
  };
  slackMessaging: SlackMessagingConfig;
  slackAttachments: SlackAttachmentsConfig;
}

export interface RuntimeConfigOverrides {
  projectRoot?: string;
  toolsDir?: string;
  host?: string;
  port?: number;
  mcpRoute?: string;
  healthRoute?: string;
  slackRoute?: string;
  authBearerToken?: string;
  serverName?: string;
  serverVersion?: string;
  slack?: {
    signingSecret?: string;
    botToken?: string;
  };
  slackMessaging?: Partial<SlackMessagingConfig>;
  slackAttachments?: Partial<SlackAttachmentsConfig>;
  mcpProxyServers?: McpProxyServerConfig[];
}

export type SlackReplyMode = "normal" | "stream";

export interface SlackMessagingConfig {
  replyMode: SlackReplyMode;
  reactionsEnabled: boolean;
}

export interface SlackAttachmentsConfig {
  enabled: boolean;
  maxFileBytes: number;
  maxCharsPerFile: number;
  maxFilesPerMessage: number;
}

const DEFAULT_HOST = "127.0.0.1";
const DEFAULT_PORT = 8080;
const DEFAULT_MCP_ROUTE = "/mcp";
const DEFAULT_HEALTH_ROUTE = "/healthz";
const DEFAULT_SLACK_ROUTE = "/api/slack";
const DEFAULT_TOOLS_DIR = "tools";
const DEFAULT_SERVER_NAME = "ai-agent-framework";
const DEFAULT_SERVER_VERSION = "0.1.0";
const DEFAULT_SLACK_REPLY_MODE: SlackReplyMode = "normal";
const DEFAULT_SLACK_REACTIONS_ENABLED = true;
const DEFAULT_SLACK_ATTACHMENTS_ENABLED = true;
const DEFAULT_SLACK_ATTACHMENT_MAX_FILE_BYTES = 2_000_000;
const DEFAULT_SLACK_ATTACHMENT_MAX_CHARS_PER_FILE = 50_000;
const DEFAULT_SLACK_ATTACHMENT_MAX_FILES_PER_MESSAGE = 8;

const mcpProxyEntrySchema = z
  .object({
    url: z.string().min(1),
    bearerToken: z.string().optional(),
    token: z.string().optional(),
    authorization: z.string().optional()
  })
  .strict();

const mcpProxyListSchema = z.array(mcpProxyEntrySchema);

let runtimeConfig = resolveRuntimeConfig();

export function configureRuntime(
  overrides: RuntimeConfigOverrides = {},
  env: NodeJS.ProcessEnv = process.env
): RuntimeConfig {
  runtimeConfig = resolveRuntimeConfig(overrides, env);
  return runtimeConfig;
}

export function getRuntimeConfig(): RuntimeConfig {
  return runtimeConfig;
}

function resolveRuntimeConfig(
  overrides: RuntimeConfigOverrides = {},
  env: NodeJS.ProcessEnv = process.env
): RuntimeConfig {
  const projectRoot = path.resolve(overrides.projectRoot ?? env.PROJECT_ROOT ?? process.cwd());
  const mergedEnv = mergeEnvFiles(projectRoot, env);
  const hostPackage = readPackageMetadata(path.join(projectRoot, "package.json"));
  const libraryPackage = readLibraryPackageMetadata();

  const host = normalizeOptionalString(overrides.host ?? mergedEnv.MCP_HOST) ?? DEFAULT_HOST;
  const port = parsePort(overrides.port ?? mergedEnv.MCP_PORT ?? mergedEnv.PORT, DEFAULT_PORT);
  const toolsDir = resolveToolsDir(
    projectRoot,
    overrides.toolsDir ?? mergedEnv.TOOLS_DIR ?? DEFAULT_TOOLS_DIR
  );
  const serverName =
    normalizeOptionalString(overrides.serverName ?? mergedEnv.MCP_SERVER_NAME) ??
    hostPackage.name ??
    DEFAULT_SERVER_NAME;
  const serverVersion =
    normalizeOptionalString(overrides.serverVersion ?? mergedEnv.MCP_SERVER_VERSION) ??
    hostPackage.version ??
    libraryPackage.version ??
    DEFAULT_SERVER_VERSION;
  const signingSecret = normalizeOptionalString(
    overrides.slack?.signingSecret ?? mergedEnv.SLACK_SIGNING_SECRET
  );
  const botToken = normalizeOptionalString(
    overrides.slack?.botToken ?? mergedEnv.SLACK_BOT_TOKEN
  );
  const slackReplyMode = parseSlackReplyMode(
    overrides.slackMessaging?.replyMode ?? mergedEnv.SLACK_REPLY_MODE
  );
  const slackReactionsEnabled = parseBoolean(
    overrides.slackMessaging?.reactionsEnabled ?? mergedEnv.SLACK_REACTIONS_ENABLED,
    DEFAULT_SLACK_REACTIONS_ENABLED,
    "SLACK_REACTIONS_ENABLED"
  );
  const slackAttachmentsEnabled = parseBoolean(
    overrides.slackAttachments?.enabled ?? mergedEnv.SLACK_ATTACHMENTS_ENABLED,
    DEFAULT_SLACK_ATTACHMENTS_ENABLED,
    "SLACK_ATTACHMENTS_ENABLED"
  );
  const slackAttachmentMaxFileBytes = parsePositiveInteger(
    overrides.slackAttachments?.maxFileBytes ?? mergedEnv.SLACK_ATTACHMENT_MAX_FILE_BYTES,
    DEFAULT_SLACK_ATTACHMENT_MAX_FILE_BYTES,
    "SLACK_ATTACHMENT_MAX_FILE_BYTES"
  );
  const slackAttachmentMaxCharsPerFile = parsePositiveInteger(
    overrides.slackAttachments?.maxCharsPerFile ?? mergedEnv.SLACK_ATTACHMENT_MAX_CHARS_PER_FILE,
    DEFAULT_SLACK_ATTACHMENT_MAX_CHARS_PER_FILE,
    "SLACK_ATTACHMENT_MAX_CHARS_PER_FILE"
  );
  const slackAttachmentMaxFilesPerMessage = parsePositiveInteger(
    overrides.slackAttachments?.maxFilesPerMessage ??
      mergedEnv.SLACK_ATTACHMENT_MAX_FILES_PER_MESSAGE,
    DEFAULT_SLACK_ATTACHMENT_MAX_FILES_PER_MESSAGE,
    "SLACK_ATTACHMENT_MAX_FILES_PER_MESSAGE"
  );

  const mcpProxyServers =
    overrides.mcpProxyServers ?? parseMcpProxyServersFromEnv(mergedEnv.MCP_PROXY_SERVERS);

  console.log("configuration: ", {
    projectRoot,
    toolsDir,
    host,
    port,
    mcpProxyServers,
    mcpRoute: normalizeRoute(overrides.mcpRoute ?? mergedEnv.MCP_ROUTE, DEFAULT_MCP_ROUTE),
    healthRoute: normalizeRoute(overrides.healthRoute ?? mergedEnv.HEALTH_ROUTE, DEFAULT_HEALTH_ROUTE),
    slackRoute: normalizeRoute(overrides.slackRoute ?? mergedEnv.SLACK_ROUTE, DEFAULT_SLACK_ROUTE),
  });

  return {
    projectRoot,
    toolsDir,
    host,
    port,
    mcpRoute: normalizeRoute(overrides.mcpRoute ?? mergedEnv.MCP_ROUTE, DEFAULT_MCP_ROUTE),
    healthRoute: normalizeRoute(
      overrides.healthRoute ?? mergedEnv.HEALTH_ROUTE,
      DEFAULT_HEALTH_ROUTE
    ),
    slackRoute: normalizeRoute(overrides.slackRoute ?? mergedEnv.SLACK_ROUTE, DEFAULT_SLACK_ROUTE),
    authBearerToken: normalizeOptionalString(
      overrides.authBearerToken ?? mergedEnv.MCP_AUTH_BEARER_TOKEN
    ),
    serverName,
    serverVersion,
    mcpProxyServers,
    slack: {
      signingSecret,
      botToken,
      enabled: Boolean(signingSecret && botToken)
    },
    slackMessaging: {
      replyMode: slackReplyMode,
      reactionsEnabled: slackReactionsEnabled
    },
    slackAttachments: {
      enabled: slackAttachmentsEnabled,
      maxFileBytes: slackAttachmentMaxFileBytes,
      maxCharsPerFile: slackAttachmentMaxCharsPerFile,
      maxFilesPerMessage: slackAttachmentMaxFilesPerMessage
    }
  };
}

function resolveToolsDir(projectRoot: string, rawToolsDir: string): string {
  if (path.isAbsolute(rawToolsDir)) {
    return rawToolsDir;
  }

  return path.resolve(projectRoot, rawToolsDir);
}

function normalizeRoute(value: string | undefined, fallback: string): string {
  const normalized = normalizeOptionalString(value) ?? fallback;
  return normalized.startsWith("/") ? normalized : `/${normalized}`;
}

function parsePort(rawValue: string | number | undefined, fallback: number): number {
  if (typeof rawValue === "number") {
    if (!Number.isInteger(rawValue) || rawValue < 1 || rawValue > 65535) {
      throw new Error(`Invalid port: ${rawValue}`);
    }
    return rawValue;
  }

  const normalized = normalizeOptionalString(rawValue);
  if (!normalized) {
    return fallback;
  }

  const parsed = Number.parseInt(normalized, 10);
  if (!Number.isInteger(parsed) || parsed < 1 || parsed > 65535) {
    throw new Error(`Invalid port: ${rawValue}`);
  }
  return parsed;
}

function parseSlackReplyMode(value: SlackReplyMode | string | undefined): SlackReplyMode {
  const normalized = normalizeOptionalString(
    typeof value === "string" ? value.toLowerCase() : value
  );

  if (!normalized) {
    return DEFAULT_SLACK_REPLY_MODE;
  }

  if (normalized === "normal" || normalized === "stream") {
    return normalized;
  }

  throw new Error('SLACK_REPLY_MODE must be either "normal" or "stream".');
}

function parseBoolean(
  value: boolean | string | undefined,
  fallback: boolean,
  envName: string
): boolean {
  if (typeof value === "boolean") {
    return value;
  }

  const normalized = normalizeOptionalString(
    typeof value === "string" ? value.toLowerCase() : value
  );
  if (!normalized) {
    return fallback;
  }

  if (["1", "true", "yes", "on"].includes(normalized)) {
    return true;
  }

  if (["0", "false", "no", "off"].includes(normalized)) {
    return false;
  }

  throw new Error(`${envName} must be a boolean value.`);
}

function parsePositiveInteger(
  rawValue: number | string | undefined,
  fallback: number,
  envName: string
): number {
  if (typeof rawValue === "number") {
    if (Number.isInteger(rawValue) && rawValue > 0) {
      return rawValue;
    }

    throw new Error(`${envName} must be a positive integer.`);
  }

  const normalized = normalizeOptionalString(rawValue);
  if (!normalized) {
    return fallback;
  }

  const parsed = Number.parseInt(normalized, 10);
  if (!Number.isInteger(parsed) || parsed < 1) {
    throw new Error(`${envName} must be a positive integer.`);
  }

  return parsed;
}

function mergeEnvFiles(projectRoot: string, env: NodeJS.ProcessEnv): NodeJS.ProcessEnv {
  const fileValues = {
    ...loadEnvFile(path.join(projectRoot, ".env")),
    ...loadEnvFile(path.join(projectRoot, ".local.env"))
  };

  return {
    ...fileValues,
    ...env
  };
}

function loadEnvFile(filePath: string): Record<string, string> {
  if (!existsSync(filePath)) {
    return {};
  }

  const parsed: Record<string, string> = {};
  const content = readFileSync(filePath, "utf8");
  for (const rawLine of content.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith("#")) {
      continue;
    }

    const separatorIndex = line.indexOf("=");
    if (separatorIndex < 1) {
      continue;
    }

    const key = line.slice(0, separatorIndex).trim();
    let value = line.slice(separatorIndex + 1).trim();
    if ((value.startsWith("\"") && value.endsWith("\"")) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    parsed[key] = value;
  }

  return parsed;
}

function normalizeOptionalString(value: string | undefined): string | undefined {
  if (typeof value !== "string") {
    return undefined;
  }

  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : undefined;
}

/**
 * Parses `MCP_PROXY_SERVERS` JSON: an array of `{ "url", "bearerToken"? | "token"? | "authorization"? }`.
 * Omitted or blank env → `[]`. Throws on invalid JSON or schema.
 */
export function parseMcpProxyServersFromEnv(raw: string | undefined): McpProxyServerConfig[] {
  console.log("parseMcpProxyServersFromEnv: ", raw);
  const normalized = normalizeOptionalString(raw);
  if (!normalized) {
    return [];
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(normalized) as unknown;
  } catch (cause) {
    throw new Error("MCP_PROXY_SERVERS must be valid JSON.", { cause });
  }

  const entries = mcpProxyListSchema.parse(parsed);
  return entries.map((entry) => {
    let authorization = normalizeOptionalString(entry.authorization);
    const bearer = normalizeOptionalString(entry.bearerToken ?? entry.token);
    if (!authorization && bearer) {
      authorization = `Bearer ${bearer}`;
    }
    return {
      url: entry.url.trim(),
      authorization
    };
  });
}

function readPackageMetadata(filePath: string): { name?: string; version?: string } {
  if (!existsSync(filePath)) {
    return {};
  }

  try {
    const raw = readFileSync(filePath, "utf8");
    const parsed = JSON.parse(raw) as { name?: string; version?: string };
    return {
      name: normalizeOptionalString(parsed.name),
      version: normalizeOptionalString(parsed.version)
    };
  } catch {
    return {};
  }
}

function readLibraryPackageMetadata(): { version?: string } {
  const moduleDir = path.dirname(fileURLToPath(import.meta.url));
  const candidatePaths = [
    path.resolve(moduleDir, "..", "package.json"),
    path.resolve(moduleDir, "..", "..", "package.json")
  ];

  for (const candidatePath of candidatePaths) {
    const metadata = readPackageMetadata(candidatePath);
    if (metadata.version) {
      return metadata;
    }
  }

  return {};
}
