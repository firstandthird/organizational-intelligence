import pdfParse from "pdf-parse";
import { getRuntimeConfig } from "./runtimeConfig.js";

const SUPPORTED_ATTACHMENT_EXTENSIONS = new Set([".txt", ".md", ".csv", ".pdf"]);
const ATTACHMENT_FETCH_TIMEOUT_MS = 10_000;

interface SlackMessageFile {
  id?: string;
  name?: string;
  mimetype?: string;
  filetype?: string;
  size?: number;
  url_private?: string;
  url_private_download?: string;
}

interface AttachmentResultIncluded {
  status: "included";
  fileName: string;
  sizeBytes: number | null;
  content: string;
}

interface AttachmentResultSkipped {
  status: "skipped";
  fileName: string;
  reason: string;
}

interface AttachmentResultFailed {
  status: "failed";
  fileName: string;
  reason: string;
}

type AttachmentResult = AttachmentResultIncluded | AttachmentResultSkipped | AttachmentResultFailed;

export function hasSlackFiles(message: unknown): boolean {
  return extractMessageFiles(message).length > 0;
}

export async function buildAttachmentContextForSlackMessage(message: unknown): Promise<string | null> {
  const runtime = getRuntimeConfig();
  const config = runtime.slackAttachments;
  if (!config.enabled) {
    return null;
  }

  const files = extractMessageFiles(message);
  if (files.length === 0) {
    return null;
  }

  const token = runtime.slack.botToken ?? process.env.SLACK_BOT_TOKEN;
  if (!token) {
    return null;
  }

  const results: AttachmentResult[] = [];
  const selectedFiles = files.slice(0, config.maxFilesPerMessage);

  for (const file of selectedFiles) {
    results.push(await ingestAttachment(file, token, config.maxFileBytes, config.maxCharsPerFile));
  }

  if (files.length > config.maxFilesPerMessage) {
    const skippedCount = files.length - config.maxFilesPerMessage;
    results.push({
      status: "skipped",
      fileName: `${skippedCount} additional file${skippedCount === 1 ? "" : "s"}`,
      reason: `exceeds max_files_per_message (${config.maxFilesPerMessage})`
    });
  }

  if (results.length === 0) {
    return null;
  }

  const sections = results.map((result) => formatAttachmentResult(result)).filter(Boolean);
  if (sections.length === 0) {
    return null;
  }

  const messageTs = getMessageTs(message);
  const header = messageTs
    ? `Slack attachments from message ${messageTs}:`
    : "Slack attachments:";

  return [header, ...sections].join("\n\n");
}

function extractMessageFiles(message: unknown): SlackMessageFile[] {
  if (!message || typeof message !== "object") {
    return [];
  }

  const value = (message as { files?: unknown }).files;
  if (!Array.isArray(value)) {
    return [];
  }

  return value.filter((entry): entry is SlackMessageFile => Boolean(entry && typeof entry === "object"));
}

function getMessageTs(message: unknown): string | null {
  if (!message || typeof message !== "object") {
    return null;
  }

  const ts = (message as { ts?: unknown }).ts;
  return typeof ts === "string" ? ts : null;
}

async function ingestAttachment(
  file: SlackMessageFile,
  token: string,
  maxFileBytes: number,
  maxCharsPerFile: number
): Promise<AttachmentResult> {
  const fileName = resolveFileName(file);
  const extension = resolveExtension(fileName);

  if (!SUPPORTED_ATTACHMENT_EXTENSIONS.has(extension)) {
    return {
      status: "skipped",
      fileName,
      reason: `unsupported type (${extension || "unknown"})`
    };
  }

  if (typeof file.size === "number" && file.size > maxFileBytes) {
    return {
      status: "skipped",
      fileName,
      reason: `size ${file.size} bytes exceeds max_file_bytes (${maxFileBytes})`
    };
  }

  const downloadUrl = resolveDownloadUrl(file);
  if (!downloadUrl) {
    return {
      status: "failed",
      fileName,
      reason: "missing private download URL"
    };
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), ATTACHMENT_FETCH_TIMEOUT_MS);

  try {
    const response = await fetch(downloadUrl, {
      headers: {
        Authorization: `Bearer ${token}`
      },
      signal: controller.signal
    });

    if (!response.ok) {
      return {
        status: "failed",
        fileName,
        reason: `download failed: ${response.status} ${response.statusText}`
      };
    }

    if (extension === ".pdf") {
      const read = await readBinaryBodyWithinByteLimit(response, maxFileBytes);
      if (read.tooLarge) {
        return {
          status: "skipped",
          fileName,
          reason: `size exceeds max_file_bytes (${maxFileBytes})`
        };
      }

      let parsedText = "";
      try {
        const parsed = await pdfParse(read.buffer);
        parsedText = normalizeAttachmentText(parsed.text ?? "");
      } catch (error) {
        return {
          status: "failed",
          fileName,
          reason: `pdf parse failed: ${error instanceof Error ? error.message : String(error)}`
        };
      }

      if (!parsedText || !/[A-Za-z0-9]/.test(parsedText)) {
        return {
          status: "skipped",
          fileName,
          reason: "pdf has no extractable text (likely scanned/image-based)"
        };
      }

      if (parsedText.length > maxCharsPerFile) {
        return {
          status: "skipped",
          fileName,
          reason: `content length ${parsedText.length} exceeds max_chars_per_file (${maxCharsPerFile})`
        };
      }

      return {
        status: "included",
        fileName,
        sizeBytes: read.bytes,
        content: parsedText
      };
    }

    const read = await readTextBodyWithinByteLimit(response, maxFileBytes);
    if (read.tooLarge) {
      return {
        status: "skipped",
        fileName,
        reason: `size exceeds max_file_bytes (${maxFileBytes})`
      };
    }

    const content = normalizeAttachmentText(read.text);
    if (!content) {
      return {
        status: "skipped",
        fileName,
        reason: "empty text content"
      };
    }

    if (content.length > maxCharsPerFile) {
      return {
        status: "skipped",
        fileName,
        reason: `content length ${content.length} exceeds max_chars_per_file (${maxCharsPerFile})`
      };
    }

    return {
      status: "included",
      fileName,
      sizeBytes: read.bytes,
      content
    };
  } catch (error) {
    const message =
      error instanceof Error && error.name === "AbortError"
        ? `download timed out after ${ATTACHMENT_FETCH_TIMEOUT_MS}ms`
        : `download error: ${error instanceof Error ? error.message : String(error)}`;

    return {
      status: "failed",
      fileName,
      reason: message
    };
  } finally {
    clearTimeout(timeout);
  }
}

function resolveFileName(file: SlackMessageFile): string {
  if (typeof file.name === "string" && file.name.trim()) {
    return file.name.trim();
  }
  if (typeof file.id === "string" && file.id.trim()) {
    return `file-${file.id.trim()}`;
  }
  return "unnamed-file";
}

function resolveExtension(fileName: string): string {
  const lastDot = fileName.lastIndexOf(".");
  if (lastDot === -1) {
    return "";
  }

  return fileName.slice(lastDot).toLowerCase();
}

function resolveDownloadUrl(file: SlackMessageFile): string | null {
  if (typeof file.url_private_download === "string" && file.url_private_download.trim()) {
    return file.url_private_download.trim();
  }
  if (typeof file.url_private === "string" && file.url_private.trim()) {
    return file.url_private.trim();
  }
  return null;
}

async function readTextBodyWithinByteLimit(
  response: Response,
  maxBytes: number
): Promise<{ text: string; bytes: number; tooLarge: boolean }> {
  const binary = await readBinaryBodyWithinByteLimit(response, maxBytes);
  if (binary.tooLarge) {
    return {
      text: "",
      bytes: binary.bytes,
      tooLarge: true
    };
  }

  return {
    text: binary.buffer.toString("utf8"),
    bytes: binary.bytes,
    tooLarge: false
  };
}

async function readBinaryBodyWithinByteLimit(
  response: Response,
  maxBytes: number
): Promise<{ buffer: Buffer; bytes: number; tooLarge: boolean }> {
  if (!response.body) {
    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    const bytes = buffer.byteLength;
    return {
      buffer,
      bytes,
      tooLarge: bytes > maxBytes
    };
  }

  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;

  while (true) {
    const { done, value } = await reader.read();
    if (done) {
      break;
    }
    if (!value) {
      continue;
    }

    if (total + value.byteLength > maxBytes) {
      await reader.cancel();
      return {
        buffer: Buffer.alloc(0),
        bytes: total + value.byteLength,
        tooLarge: true
      };
    }

    total += value.byteLength;
    chunks.push(value);
  }

  const buffer = Buffer.concat(chunks.map((chunk) => Buffer.from(chunk)));
  return {
    buffer,
    bytes: buffer.byteLength,
    tooLarge: false
  };
}

function normalizeAttachmentText(value: string): string {
  return value
    .replace(/\r\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function formatAttachmentResult(result: AttachmentResult): string {
  if (result.status === "included") {
    const sizeSegment = typeof result.sizeBytes === "number" ? `${result.sizeBytes} bytes` : "unknown size";
    return [`[attachment included: ${result.fileName} (${sizeSegment})]`, result.content].join(
      "\n"
    );
  }

  if (result.status === "skipped") {
    return `[attachment skipped: ${result.fileName} (${result.reason})]`;
  }

  return `[attachment unavailable: ${result.fileName} (${result.reason})]`;
}
