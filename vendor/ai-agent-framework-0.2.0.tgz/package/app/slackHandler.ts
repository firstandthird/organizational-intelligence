import type { Request, Response } from "express";
import SlackBolt from "@slack/bolt";
import {
  buildAttachmentContextForSlackMessage,
  hasSlackFiles
} from "./slackAttachments.js";
import { runSlackLlmTurn } from "./llm.js";
import { getRuntimeConfig } from "./runtimeConfig.js";
import { postThreadReply, type SlackMessagingClient } from "./slackMessaging.js";
import { ensureToolModulesLoaded, getLoadedTools } from "./toolLoader.js";

const { App, ExpressReceiver, LogLevel } = SlackBolt;

interface SlackRuntime {
  receiver: InstanceType<typeof ExpressReceiver>;
}

let slackRuntime: SlackRuntime | null = null;
let slackRuntimeSignature: string | null = null;

function slackSigningDebugEnabled(): boolean {
  return /^1|true|yes|on$/i.test(process.env.SLACK_DEBUG_SIGNING ?? "");
}

/** Set `SLACK_TRACE=1` (or true/yes/on) to log `[slack trace]` lines for event routing and replies. */
function slackTraceEnabled(): boolean {
  return /^1|true|yes|on$/i.test(process.env.SLACK_TRACE ?? "");
}

function slackTrace(message: string, fields?: Record<string, unknown>): void {
  if (!slackTraceEnabled()) {
    return;
  }
  if (fields && Object.keys(fields).length > 0) {
    console.warn(`[slack trace] ${message}`, fields);
  } else {
    console.warn(`[slack trace] ${message}`);
  }
}

function maskSlackSignature(sig: string | undefined): string {
  if (!sig) {
    return "(missing)";
  }
  return `${sig.slice(0, Math.min(14, sig.length))}…(len=${sig.length})`;
}

function maskSigningSecret(secret: string): string {
  if (!secret) {
    return "(empty — SLACK_SIGNING_SECRET not loaded)";
  }
  if (secret !== secret.trim()) {
    return `len=${secret.length} (WARNING: leading/trailing whitespace — copy secret without spaces/newlines)`;
  }
  if (secret.length <= 8) {
    return `len=${secret.length} (value too short for a typical Slack signing secret)`;
  }
  return `${secret.slice(0, 4)}…${secret.slice(-4)} (len=${secret.length}, compare Slack app → Basic Information → Signing Secret)`;
}

function logSlackSigningDebug(req: Request, signingSecret: string): void {
  const raw = (req as Request & { rawBody?: Buffer }).rawBody;
  const ts = req.headers["x-slack-request-timestamp"];
  const sig = req.headers["x-slack-signature"];
  const slackHeaderEntries = Object.entries(req.headers).filter(([key]) =>
    key.toLowerCase().startsWith("x-slack")
  );
  const slackHeaders: Record<string, string | string[] | undefined> = {};
  for (const [key, value] of slackHeaderEntries) {
    slackHeaders[key] =
      key.toLowerCase() === "x-slack-signature" ? maskSlackSignature(String(value ?? "")) : value;
  }

  const rawUtf8 = raw?.toString("utf8") ?? "";
  console.warn("[SLACK_DEBUG_SIGNING] Slack signs: HMAC_SHA256(signingSecret, `v0:${String(ts)}:${rawBody}`)", {
    signingSecret: maskSigningSecret(signingSecret),
    slackHeaders,
    otherRelevantHeaders: {
      "content-type": req.headers["content-type"],
      "content-length": req.headers["content-length"],
      host: req.headers.host
    },
    rawBodyByteLength: raw?.length ?? 0,
    rawBodyUtf8Preview: rawUtf8.length ? `${rawUtf8.slice(0, 240)}${rawUtf8.length > 240 ? "…" : ""}` : "(missing — express must capture raw body; see app.ts express.json verify)",
    parsedBodyType: req.body === undefined ? "undefined" : Array.isArray(req.body) ? "array" : typeof req.body
  });
}

export async function slackHandler(req: Request, res: Response): Promise<void> {
  const runtime = getRuntimeConfig();
  const receiver = await getSlackReceiver();

  if (!receiver) {
    slackTrace("slackHandler: Slack not configured (missing signing secret or bot token)");
    res.status(503).json({
      error: `Slack is not configured. Set SLACK_SIGNING_SECRET and SLACK_BOT_TOKEN to enable ${runtime.slackRoute}.`
    });
    return;
  }

  slackTrace("slackHandler: forwarding to Bolt", {
    method: req.method,
    route: runtime.slackRoute
  });

  if (slackSigningDebugEnabled() && runtime.slack.signingSecret) {
    logSlackSigningDebug(req, runtime.slack.signingSecret);
  }

  await receiver.app(req, res);
}

export async function buildInstalledSkillsMessage(): Promise<string> {
  const runtime = getRuntimeConfig();
  const loaded = await ensureToolModulesLoaded(runtime.toolsDir);

  if (loaded.tools.length === 0) {
    return [
      `${runtime.serverName} is running, but no MCP skills were loaded from ${runtime.toolsDir}.`,
      `Add tool modules under ${runtime.toolsDir} to expose them over ${runtime.mcpRoute}.`
    ].join("\n");
  }

  const lines = getLoadedTools().map((tool) => `- ${tool.name}: ${tool.description}`);
  return [`${runtime.serverName} exposes these MCP skills on ${runtime.mcpRoute}:`, ...lines].join(
    "\n"
  );
}

export function resetSlackRuntime(): void {
  slackRuntime = null;
  slackRuntimeSignature = null;
}

function isLikelyDirectMessage(event: SlackMessageEvent): boolean {
  if (event.channel_type === "im") {
    return true;
  }
  // Some deliveries omit channel_type; 1:1 DM channel IDs start with "D".
  const ch = event.channel ?? "";
  return /^D[A-Z0-9]+$/i.test(ch);
}

async function getSlackReceiver(): Promise<SlackRuntime["receiver"] | null> {
  const runtime = getRuntimeConfig();
  if (!runtime.slack.enabled || !runtime.slack.signingSecret || !runtime.slack.botToken) {
    return null;
  }

  const signature = [
    runtime.slackRoute,
    runtime.slack.signingSecret,
    runtime.slack.botToken
  ].join("|");

  if (slackRuntime && slackRuntimeSignature === signature) {
    return slackRuntime.receiver;
  }

  slackTrace("getSlackReceiver: initializing Bolt ExpressReceiver + App (handlers registered)");

  const receiver = new ExpressReceiver({
    signingSecret: runtime.slack.signingSecret,
    endpoints: runtime.slackRoute,
    processBeforeResponse: false
  });

  const app = new App({
    token: runtime.slack.botToken,
    receiver,
    logLevel: LogLevel.INFO
  });

  app.event("app_mention", async ({ event, client }) => {
    const ev = event as SlackMessageEvent;
    slackTrace("app_mention: handling", {
      channel: ev.channel,
      channel_type: ev.channel_type,
      hasText: Boolean(ev.text?.trim())
    });
    await replyToSlackEvent(
      ev,
      client as unknown as SlackMessagingClient,
      true
    );
    slackTrace("app_mention: replyToSlackEvent finished");
  });

  app.event("message", async ({ event, client }) => {
    const messageEvent = event as SlackMessageEvent;

    slackTrace("message: received", {
      channel: messageEvent.channel,
      channel_type: messageEvent.channel_type,
      subtype: messageEvent.subtype ?? "(none)",
      bot_id: messageEvent.bot_id ?? "(none)"
    });

    if (messageEvent.bot_id) {
      slackTrace("message: skipped (from bot)", { bot_id: messageEvent.bot_id });
      return;
    }
    if (messageEvent.subtype) {
      slackTrace("message: skipped (has subtype)", { subtype: messageEvent.subtype });
      return;
    }
    if (!isLikelyDirectMessage(messageEvent)) {
      slackTrace("message: skipped (not treated as 1:1 DM)", {
        channel: messageEvent.channel,
        channel_type: messageEvent.channel_type,
        hint: "expects channel_type im or channel id matching /^D[A-Z0-9]+$/i"
      });
      return;
    }

    slackTrace("message: handling as DM");
    await replyToSlackEvent(messageEvent, client as unknown as SlackMessagingClient, false);
    slackTrace("message: replyToSlackEvent finished");
  });

  slackRuntime = {
    receiver
  };
  slackRuntimeSignature = signature;

  return receiver;
}

async function buildSlackReply(input: {
  text: string;
  channelId: string;
  threadTs: string;
  userId?: string;
  attachmentContext?: string | null;
}): Promise<string> {
  const prompt = input.text.trim();

  if (!prompt && !input.attachmentContext?.trim()) {
    return "How can I help?";
  }

  try {
    const result = await runSlackLlmTurn({
      text: prompt,
      channelId: input.channelId,
      threadTs: input.threadTs,
      userId: input.userId,
      attachmentContext: input.attachmentContext
    });

    return result.text;
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return `Unable to complete that request: ${message}`;
  }
}

function normalizeSlackPrompt(text: string | undefined): string {
  return (text ?? "").replace(/<@\w+>/g, "").trim();
}

interface SlackMessageEvent {
  channel?: string;
  bot_id?: string;
  channel_type?: string;
  subtype?: string;
  text?: string;
  user?: string;
  thread_ts?: string;
  ts?: string;
  files?: unknown[];
}

async function replyToSlackEvent(
  event: SlackMessageEvent,
  client: SlackMessagingClient,
  removeMentions: boolean
): Promise<void> {
  const runtime = getRuntimeConfig();
  const channelId = event.channel ?? "";
  const threadTs = event.thread_ts ?? event.ts ?? "";

  slackTrace("replyToSlackEvent: enter", {
    removeMentions,
    channelId: channelId || "(missing)",
    threadTs: threadTs || "(missing)",
    user: event.user ?? "(none)"
  });

  if (!channelId || !threadTs) {
    slackTrace("replyToSlackEvent: abort (missing channel or thread/ts)");
    return;
  }

  const prompt = removeMentions ? normalizeSlackPrompt(event.text) : (event.text ?? "").trim();
  const attachmentContext = hasSlackFiles(event)
    ? await buildAttachmentContextForSlackMessage(event)
    : null;
  const effectivePrompt = prompt || (attachmentContext ? "Please analyze the attached file(s)." : "");
  slackTrace("replyToSlackEvent: calling LLM / buildSlackReply", {
    promptChars: effectivePrompt.length,
    hasAttachmentContext: Boolean(attachmentContext)
  });
  const message = await buildSlackReply({
    text: effectivePrompt,
    channelId,
    threadTs,
    userId: event.user,
    attachmentContext
  });

  slackTrace("replyToSlackEvent: posting reply", { replyChars: message.length });
  await postThreadReply(client, channelId, threadTs, message, {
    mode: runtime.slackMessaging.replyMode
  });
  slackTrace("replyToSlackEvent: postThreadReply finished");
}
