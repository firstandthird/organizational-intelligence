import fs from "node:fs";
import path from "node:path";

let logStream: fs.WriteStream | null = null;
let logFilePath: string | null = null;
let closeHookRegistered = false;
let consolePatched = false;
const originalConsoleLog = console.log.bind(console);
const DEBUG_ENV_PATTERN = /^(1|true|yes|on)$/i;
const DEFAULT_DEBUG_VALUE_PREVIEW_CHARS = 240;

export type ToolDebugEvent =
  | "tool_requested"
  | "tool_rejected"
  | "tool_started"
  | "tool_finished"
  | "tool_failed";

interface ToolDebugEventInput {
  toolName: string;
  callId?: string;
  args?: unknown;
  result?: unknown;
  durationMs?: number;
  reason?: string;
  error?: unknown;
}

export function configureLogSink(logPath?: string): void {
  if (!logPath) {
    return;
  }

  const resolvedPath = path.resolve(process.cwd(), logPath);
  const parentDir = path.dirname(resolvedPath);
  if (!fs.existsSync(parentDir)) {
    throw new Error(`Log directory does not exist: ${parentDir}`);
  }
  if (!fs.statSync(parentDir).isDirectory()) {
    throw new Error(`Log directory is not a directory: ${parentDir}`);
  }

  const fd = fs.openSync(resolvedPath, "a");
  fs.closeSync(fd);

  if (logStream) {
    logStream.end();
  }

  logFilePath = resolvedPath;
  logStream = fs.createWriteStream(resolvedPath, { flags: "a" });
  patchConsoleForOpenAIDebug();
  if (!closeHookRegistered) {
    process.once("exit", closeLogSink);
    closeHookRegistered = true;
  }
}

export function getLogSinkPath(): string | null {
  return logFilePath;
}

export function closeLogSink(): void {
  if (!logStream) {
    return;
  }

  logStream.end();
  logStream = null;
}

export function logInfo(...args: unknown[]): void {
  write("INFO", args, console.log);
}

export function isDebugLoggingEnabled(): boolean {
  return DEBUG_ENV_PATTERN.test(process.env.DEBUG ?? "");
}

export function logDebug(...args: unknown[]): void {
  if (!isDebugLoggingEnabled()) {
    return;
  }

  write("INFO", ["DEBUG", ...args], console.log);
}

export function logWarn(...args: unknown[]): void {
  write("WARN", args, console.warn);
}

export function logError(...args: unknown[]): void {
  write("ERROR", args, console.error);
}

export function buildLogValuePreview(value: unknown, maxChars = DEFAULT_DEBUG_VALUE_PREVIEW_CHARS): string {
  if (typeof value === "string") {
    return buildLogTextPreview(value, maxChars);
  }

  let serialized: string;
  try {
    serialized = JSON.stringify(redactSensitive(value));
  } catch {
    serialized = String(value);
  }

  if (!Number.isFinite(maxChars) || maxChars < 1 || serialized.length <= maxChars) {
    return serialized;
  }

  return `${serialized.slice(0, Math.max(1, maxChars - 1)).trimEnd()}…`;
}

export function logToolDebugEvent(event: ToolDebugEvent, input: ToolDebugEventInput): void {
  if (!isDebugLoggingEnabled()) {
    return;
  }

  const payload: Record<string, unknown> = {
    toolName: input.toolName
  };

  if (input.callId) {
    payload.callId = input.callId;
  }

  if (typeof input.durationMs === "number" && Number.isFinite(input.durationMs)) {
    payload.durationMs = Math.max(0, Math.round(input.durationMs));
  }

  if (input.reason) {
    payload.reason = input.reason;
  }

  if (typeof input.args !== "undefined") {
    payload.argsPreview = buildLogValuePreview(input.args);
  }

  if (typeof input.result !== "undefined") {
    payload.resultPreview = buildLogValuePreview(input.result);
  }

  if (typeof input.error !== "undefined") {
    payload.error = summarizeError(input.error);
  }

  logDebug(event, payload);
}

export function buildLogTextPreview(text: string, maxChars = 140): string {
  const normalized = text.replace(/\s+/g, " ").trim();
  if (!normalized) {
    return "";
  }

  if (!Number.isFinite(maxChars) || maxChars < 1 || normalized.length <= maxChars) {
    return normalized;
  }

  return `${normalized.slice(0, Math.max(1, maxChars - 1)).trimEnd()}…`;
}

function write(
  level: "INFO" | "WARN" | "ERROR",
  args: unknown[],
  fallback: (...items: unknown[]) => void
): void {
  if (!logStream) {
    fallback(...args);
    return;
  }

  const timestamp = new Date().toISOString();
  const message = args.map((arg) => formatArg(arg)).join(" ");
  logStream.write(`${timestamp} [${level}] ${message}\n`);
}

function patchConsoleForOpenAIDebug(): void {
  if (consolePatched) {
    return;
  }

  console.log = (...args: unknown[]) => {
    if (shouldCaptureOpenAIDebug(args)) {
      write("INFO", args, originalConsoleLog);
      return;
    }

    originalConsoleLog(...args);
  };

  consolePatched = true;
}

function shouldCaptureOpenAIDebug(args: unknown[]): boolean {
  if (!logStream) {
    return false;
  }

  const first = args[0];
  return typeof first === "string" && first.startsWith("OpenAI:DEBUG:");
}

function formatArg(value: unknown): string {
  if (typeof value === "string") {
    return value;
  }

  if (value instanceof Error) {
    return value.stack ?? `${value.name}: ${value.message}`;
  }

  if (typeof value === "number" || typeof value === "boolean" || value === null || typeof value === "undefined") {
    return String(value);
  }

  try {
    return JSON.stringify(redactSensitive(value));
  } catch {
    return String(value);
  }
}

function summarizeError(error: unknown): string {
  if (error instanceof Error) {
    return error.message;
  }

  return String(error);
}

function redactSensitive(value: unknown, depth = 0): unknown {
  if (depth > 8 || value === null || typeof value !== "object") {
    return value;
  }

  if (Array.isArray(value)) {
    return value.map((item) => redactSensitive(item, depth + 1));
  }

  const source = value as Record<string, unknown>;
  const redacted: Record<string, unknown> = {};
  for (const [key, nestedValue] of Object.entries(source)) {
    const lowered = key.toLowerCase();
    if (
      lowered === "apikey" ||
      lowered === "api_key" ||
      lowered === "authorization" ||
      lowered.endsWith("_token") ||
      lowered === "token"
    ) {
      redacted[key] = "REDACTED";
      continue;
    }
    redacted[key] = redactSensitive(nestedValue, depth + 1);
  }

  return redacted;
}
