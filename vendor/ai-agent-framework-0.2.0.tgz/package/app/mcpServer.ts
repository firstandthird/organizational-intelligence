import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import type { RequestHandlerExtra } from "@modelcontextprotocol/sdk/shared/protocol.js";
import {
  ErrorCode,
  GetPromptRequestSchema,
  ListPromptsRequestSchema,
  McpError,
  type ServerNotification,
  type ServerRequest
} from "@modelcontextprotocol/sdk/types.js";
import { getRuntimeConfig } from "./runtimeConfig.js";
import { ensureToolModulesLoaded } from "./toolLoader.js";
import type { LoadedPromptProvider, LoadedToolDefinition, ToolResult } from "../types/tool.js";

export async function createMcpServer(): Promise<McpServer> {
  const runtime = getRuntimeConfig();
  const loaded = await ensureToolModulesLoaded(runtime.toolsDir);
  const server = new McpServer({
    name: runtime.serverName,
    version: runtime.serverVersion
  });

  for (const tool of loaded.tools) {
    server.registerTool(
      tool.name,
      {
        title: tool.title ?? humanizeToolName(tool.name),
        description: tool.description,
        inputSchema: tool.inputSchema,
        outputSchema: tool.outputSchema
      },
      async (
        args: unknown,
        extra: RequestHandlerExtra<ServerRequest, ServerNotification>
      ) => {
        try {
          const result = await tool.execute((args ?? {}) as Record<string, unknown>, {
            request: {
              requestId: String(extra.requestId),
              sessionId: extra.sessionId ?? undefined,
              transport: "mcp"
            }
          });

          return formatToolResult(result);
        } catch (error) {
          return {
            isError: true,
            content: [
              {
                type: "text" as const,
                text: getErrorMessage(error, tool)
              }
            ]
          };
        }
      }
    );
  }

  if (loaded.prompts.length > 0) {
    registerPromptProviders(server, loaded.prompts);
  }

  return server;
}

function registerPromptProviders(server: McpServer, providers: LoadedPromptProvider[]): void {
  server.server.assertCanSetRequestHandler("prompts/list");
  server.server.assertCanSetRequestHandler("prompts/get");
  server.server.registerCapabilities({
    prompts: {
      listChanged: true
    }
  });
  server.server.setRequestHandler(ListPromptsRequestSchema, async (request) => {
    if (providers.length === 1) {
      return providers[0]!.list(request.params ?? {});
    }

    const prompts = [];
    const names = new Set<string>();
    for (const provider of providers) {
      const result = await provider.list(request.params ?? {});
      for (const prompt of result.prompts) {
        if (names.has(prompt.name)) {
          throw new McpError(ErrorCode.InternalError, `Duplicate prompt name detected: ${prompt.name}`);
        }
        names.add(prompt.name);
        prompts.push(prompt);
      }
    }

    return { prompts };
  });
  server.server.setRequestHandler(GetPromptRequestSchema, async (request) => {
    const provider = await findPromptProvider(providers, request.params.name);
    if (!provider) {
      throw new McpError(ErrorCode.InvalidParams, `Prompt ${request.params.name} not found`);
    }

    return provider.get(request.params);
  });
}

async function findPromptProvider(
  providers: LoadedPromptProvider[],
  name: string
): Promise<LoadedPromptProvider | undefined> {
  for (const provider of providers) {
    const result = await provider.list({});
    if (result.prompts.some((prompt) => prompt.name === name)) {
      return provider;
    }
  }

  return undefined;
}

function formatToolResult(result: ToolResult) {
  if (typeof result === "string") {
    return {
      content: [
        {
          type: "text" as const,
          text: result
        }
      ],
      structuredContent: {
        summary: result
      }
    };
  }

  if (result && typeof result === "object") {
    return {
      content: [
        {
          type: "text" as const,
          text: JSON.stringify(result, null, 2)
        }
      ],
      structuredContent: result as Record<string, unknown>
    };
  }

  return {
    content: [
      {
        type: "text" as const,
        text: JSON.stringify({ value: result }, null, 2)
      }
    ],
    structuredContent: {
      value: result
    }
  };
}

function humanizeToolName(name: string): string {
  return name
    .split(/[_-]+/)
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

function getErrorMessage(error: unknown, tool: LoadedToolDefinition): string {
  if (error instanceof Error) {
    return `${tool.name} failed: ${error.message}`;
  }

  return `${tool.name} failed.`;
}
