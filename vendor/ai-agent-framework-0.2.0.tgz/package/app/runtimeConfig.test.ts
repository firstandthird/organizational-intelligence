import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import { configureRuntime } from "./runtimeConfig.js";

function withEnv<T>(
  overrides: Record<string, string | undefined>,
  run: () => T | Promise<T>
): Promise<T> {
  const previous = new Map<string, string | undefined>();

  for (const [key, value] of Object.entries(overrides)) {
    previous.set(key, process.env[key]);
    if (typeof value === "string") {
      process.env[key] = value;
    } else {
      delete process.env[key];
    }
  }

  return Promise.resolve(run()).finally(() => {
    for (const [key, value] of previous.entries()) {
      if (typeof value === "string") {
        process.env[key] = value;
      } else {
        delete process.env[key];
      }
    }
  });
}

async function withTempDataDir(
  build: (dataRoot: string) => void,
  run: (dataRoot: string) => void | Promise<void>
): Promise<void> {
  const dataRoot = fs.mkdtempSync(path.join(os.tmpdir(), "agents-runtime-config-"));

  try {
    build(dataRoot);
    await run(dataRoot);
  } finally {
    fs.rmSync(dataRoot, { recursive: true, force: true });
  }
}

test("requires --data when GITHUB_REPO is not set", async () => {
  await withEnv({ GITHUB_REPO: undefined }, () => {
    assert.throws(() => {
      configureRuntime({});
    }, /Provide --data <path>/);
  });
});

test("uses github mode when GITHUB_REPO is set and --data is not provided", async () => {
  await withEnv({ GITHUB_REPO: "octocat/Hello-World", GITHUB_REF: undefined }, () => {
    const runtime = configureRuntime({});

    assert.equal(runtime.contentSource.type, "github");
    if (runtime.contentSource.type === "github") {
      assert.equal(runtime.contentSource.owner, "octocat");
      assert.equal(runtime.contentSource.repo, "Hello-World");
      assert.equal(runtime.contentSource.ref, "main");
    }
  });
});

test("forces local mode when --data is provided even if GITHUB_REPO is set", async () => {
  await withTempDataDir(
    (dataRoot) => {
      fs.mkdirSync(path.join(dataRoot, "skills"), { recursive: true });
    },
    async (dataRoot) => {
      await withEnv({ GITHUB_REPO: "octocat/Hello-World" }, () => {
        const runtime = configureRuntime({ dataPath: dataRoot });

        assert.equal(runtime.contentSource.type, "local");
        assert.equal(runtime.agentsDir, path.join(dataRoot, "skills"));
        assert.equal(runtime.assetsDir, path.join(dataRoot, "assets"));
        assert.equal(runtime.dataPath, dataRoot);
      });
    }
  );
});

test("requires skills subdirectory under --data path", async () => {
  await withTempDataDir(
    () => {},
    async (dataRoot) => {
      await withEnv({ GITHUB_REPO: undefined }, () => {
        assert.throws(() => {
          configureRuntime({ dataPath: dataRoot });
        }, /Data skills directory does not exist/);
      });
    }
  );
});

test("allows missing assets subdirectory under --data path", async () => {
  await withTempDataDir(
    (dataRoot) => {
      fs.mkdirSync(path.join(dataRoot, "skills"), { recursive: true });
    },
    async (dataRoot) => {
      await withEnv({ GITHUB_REPO: undefined }, () => {
        const runtime = configureRuntime({ dataPath: dataRoot });
        assert.equal(runtime.contentSource.type, "local");
        assert.equal(runtime.assetsDir, path.join(dataRoot, "assets"));
      });
    }
  );
});

test("rejects --data/assets when assets exists but is not a directory", async () => {
  await withTempDataDir(
    (dataRoot) => {
      fs.mkdirSync(path.join(dataRoot, "skills"), { recursive: true });
      fs.writeFileSync(path.join(dataRoot, "assets"), "not a directory");
    },
    async (dataRoot) => {
      await withEnv({ GITHUB_REPO: undefined }, () => {
        assert.throws(() => {
          configureRuntime({ dataPath: dataRoot });
        }, /Data assets directory is not a directory/);
      });
    }
  );
});

test("defaults slack reply mode to normal when SLACK_REPLY_MODE is not set", async () => {
  await withEnv(
    {
      GITHUB_REPO: "octocat/Hello-World",
      GITHUB_REF: undefined,
      SLACK_REPLY_MODE: undefined,
      SLACK_REACTIONS_ENABLED: undefined
    },
    () => {
      const runtime = configureRuntime({});
      assert.equal(runtime.slackMessaging.replyMode, "normal");
      assert.equal(runtime.slackMessaging.reactionsEnabled, true);
    }
  );
});

test("uses aggressive default slack attachment limits", async () => {
  await withEnv(
    {
      GITHUB_REPO: "octocat/Hello-World",
      GITHUB_REF: undefined
    },
    () => {
      const runtime = configureRuntime({});
      assert.deepEqual(runtime.slackAttachments, {
        enabled: true,
        maxFileBytes: 2_000_000,
        maxCharsPerFile: 50_000,
        maxFilesPerMessage: 8
      });
    }
  );
});

test("uses stream mode when SLACK_REPLY_MODE=stream", async () => {
  await withEnv(
    {
      GITHUB_REPO: "octocat/Hello-World",
      GITHUB_REF: undefined,
      SLACK_REPLY_MODE: "stream"
    },
    () => {
      const runtime = configureRuntime({});
      assert.equal(runtime.slackMessaging.replyMode, "stream");
      assert.equal(runtime.slackMessaging.reactionsEnabled, true);
    }
  );
});

test("rejects invalid SLACK_REPLY_MODE", async () => {
  await withEnv(
    {
      GITHUB_REPO: "octocat/Hello-World",
      GITHUB_REF: undefined,
      SLACK_REPLY_MODE: "invalid"
    },
    () => {
      assert.throws(() => {
        configureRuntime({});
      }, /SLACK_REPLY_MODE must be either "normal" or "stream"/);
    }
  );
});

test("disables slack reactions when SLACK_REACTIONS_ENABLED=false", async () => {
  await withEnv(
    {
      GITHUB_REPO: "octocat/Hello-World",
      GITHUB_REF: undefined,
      SLACK_REACTIONS_ENABLED: "false"
    },
    () => {
      const runtime = configureRuntime({});
      assert.equal(runtime.slackMessaging.reactionsEnabled, false);
      assert.equal(runtime.slackMessaging.replyMode, "normal");
    }
  );
});

test("accepts truthy slack reaction env values", async () => {
  await withEnv(
    {
      GITHUB_REPO: "octocat/Hello-World",
      GITHUB_REF: undefined,
      SLACK_REACTIONS_ENABLED: "yes"
    },
    () => {
      const runtime = configureRuntime({});
      assert.equal(runtime.slackMessaging.reactionsEnabled, true);
    }
  );
});

test("rejects invalid SLACK_REACTIONS_ENABLED values", async () => {
  await withEnv(
    {
      GITHUB_REPO: "octocat/Hello-World",
      GITHUB_REF: undefined,
      SLACK_REACTIONS_ENABLED: "maybe"
    },
    () => {
      assert.throws(() => {
        configureRuntime({});
      }, /SLACK_REACTIONS_ENABLED must be a boolean value/);
    }
  );
});
