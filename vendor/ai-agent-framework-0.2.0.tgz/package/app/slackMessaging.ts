import type { SlackReplyMode } from "./runtimeConfig.js";
import { formatForSlackMrkdwn } from "./slackFormatting.js";

const DEFAULT_STREAM_CHUNK_SIZE = 280;

interface SlackChatApi {
  postMessage: (args: Record<string, unknown>) => Promise<{ ts?: string }>;
  update?: (args: Record<string, unknown>) => Promise<unknown>;
  delete?: (args: Record<string, unknown>) => Promise<unknown>;
  startStream?: (args: Record<string, unknown>) => Promise<{ ts?: string }>;
  appendStream?: (args: Record<string, unknown>) => Promise<unknown>;
  stopStream?: (args: Record<string, unknown>) => Promise<unknown>;
}

interface SlackFilesApi {
  uploadV2?: (args: Record<string, unknown>) => Promise<unknown>;
}

interface SlackReactionsApi {
  add?: (args: Record<string, unknown>) => Promise<unknown>;
}

export interface SlackMessagingClient {
  chat: SlackChatApi;
  files?: SlackFilesApi;
  reactions?: SlackReactionsApi;
  apiCall?: (method: string, options?: Record<string, unknown>) => Promise<unknown>;
}

export interface PostThreadReplyOptions {
  mode: SlackReplyMode;
  recipientUserId?: string;
  recipientTeamId?: string;
  streamChunkSize?: number;
  onStreamError?: (error: unknown) => void;
  messageMetadata?: Record<string, unknown>;
}

export async function postThreadReply(
  client: SlackMessagingClient,
  channelId: string,
  threadTs: string,
  text: string,
  options: PostThreadReplyOptions
): Promise<void> {
  if (options.mode !== "stream") {
    await postSlackMessage(client, {
      channel: channelId,
      thread_ts: threadTs,
      text,
      ...(options.messageMetadata ? { metadata: options.messageMetadata } : {})
    });
    return;
  }

  const formattedText = formatForSlackMrkdwn(text);
  if (!formattedText) {
    await postSlackMessage(client, {
      channel: channelId,
      thread_ts: threadTs,
      text,
      ...(options.messageMetadata ? { metadata: options.messageMetadata } : {})
    });
    return;
  }

  try {
    await streamSlackThreadReply(client, channelId, threadTs, formattedText, options);
  } catch (error) {
    options.onStreamError?.(error);
    await postSlackMessage(client, {
      channel: channelId,
      thread_ts: threadTs,
      text,
      ...(options.messageMetadata ? { metadata: options.messageMetadata } : {})
    });
  }
}

export async function postSlackMessage(
  client: SlackMessagingClient,
  args: Record<string, unknown>
): Promise<{ ts?: string }> {
  return client.chat.postMessage(withFormattedSlackText(args));
}

export async function uploadSlackTextSnippet(
  client: SlackMessagingClient,
  input: {
    channelId: string;
    threadTs: string;
    filename: string;
    content: string;
    title?: string;
  }
): Promise<void> {
  const args: Record<string, unknown> = {
    channel_id: input.channelId,
    thread_ts: input.threadTs,
    filename: input.filename,
    title: input.title ?? input.filename,
    content: input.content,
    filetype: "text"
  };

  if (typeof client.files?.uploadV2 === "function") {
    await client.files.uploadV2(args);
    return;
  }

  await callSlackApiMethod(client, "files.uploadV2", args);
}

export async function addSlackReaction(
  client: SlackMessagingClient,
  input: {
    channel: string;
    timestamp: string;
    name: string;
  }
): Promise<void> {
  const args: Record<string, unknown> = {
    channel: input.channel,
    timestamp: input.timestamp,
    name: input.name
  };

  try {
    if (typeof client.reactions?.add === "function") {
      await client.reactions.add(args);
      return;
    }

    await callSlackApiMethod(client, "reactions.add", args);
  } catch (error) {
    if (isSlackAlreadyReactedError(error)) {
      return;
    }

    throw error;
  }
}

export async function updateSlackMessage(
  client: SlackMessagingClient,
  args: Record<string, unknown>
): Promise<void> {
  const formatted = withFormattedSlackText(args);
  if (typeof client.chat.update === "function") {
    await client.chat.update(formatted);
    return;
  }

  await callSlackApiMethod(client, "chat.update", formatted);
}

export async function deleteSlackMessage(
  client: SlackMessagingClient,
  args: Record<string, unknown>
): Promise<void> {
  if (typeof client.chat.delete === "function") {
    await client.chat.delete(args);
    return;
  }

  await callSlackApiMethod(client, "chat.delete", args);
}

function withFormattedSlackText(args: Record<string, unknown>): Record<string, unknown> {
  const text = typeof args.text === "string" ? formatForSlackMrkdwn(args.text) : args.text;
  return {
    ...args,
    text,
    mrkdwn: true
  };
}

async function streamSlackThreadReply(
  client: SlackMessagingClient,
  channelId: string,
  threadTs: string,
  formattedText: string,
  options: PostThreadReplyOptions
): Promise<void> {
  const chunkSize = resolveStreamChunkSize(options.streamChunkSize);
  let index = 0;
  const firstChunk = formattedText.slice(index, index + chunkSize);
  index += firstChunk.length;

  const startArgs: Record<string, unknown> = {
    channel: channelId,
    thread_ts: threadTs,
    markdown_text: firstChunk
  };

  if (options.messageMetadata) {
    startArgs.metadata = options.messageMetadata;
  }
  if (options.recipientUserId) {
    startArgs.recipient_user_id = options.recipientUserId;
  }
  if (options.recipientTeamId) {
    startArgs.recipient_team_id = options.recipientTeamId;
  }

  const started = await startSlackStream(client, startArgs);
  const streamTs =
    typeof started.ts === "string" && started.ts.trim().length > 0 ? started.ts : threadTs;

  while (index < formattedText.length) {
    const nextChunk = formattedText.slice(index, index + chunkSize);
    index += nextChunk.length;
    await appendSlackStream(client, {
      channel: channelId,
      ts: streamTs,
      markdown_text: nextChunk
    });
  }

  await stopSlackStream(client, {
    channel: channelId,
    ts: streamTs
  });
}

function resolveStreamChunkSize(value: number | undefined): number {
  if (typeof value !== "number") {
    return DEFAULT_STREAM_CHUNK_SIZE;
  }

  if (!Number.isFinite(value) || !Number.isInteger(value) || value < 1) {
    return DEFAULT_STREAM_CHUNK_SIZE;
  }

  return value;
}

async function startSlackStream(
  client: SlackMessagingClient,
  args: Record<string, unknown>
): Promise<{ ts?: string }> {
  if (typeof client.chat.startStream === "function") {
    return client.chat.startStream(args);
  }

  const response = await callSlackApiMethod(client, "chat.startStream", args);
  return response as { ts?: string };
}

async function appendSlackStream(
  client: SlackMessagingClient,
  args: Record<string, unknown>
): Promise<void> {
  if (typeof client.chat.appendStream === "function") {
    await client.chat.appendStream(args);
    return;
  }

  await callSlackApiMethod(client, "chat.appendStream", args);
}

async function stopSlackStream(
  client: SlackMessagingClient,
  args: Record<string, unknown>
): Promise<void> {
  if (typeof client.chat.stopStream === "function") {
    await client.chat.stopStream(args);
    return;
  }

  await callSlackApiMethod(client, "chat.stopStream", args);
}

async function callSlackApiMethod(
  client: SlackMessagingClient,
  method: string,
  args: Record<string, unknown>
): Promise<unknown> {
  if (typeof client.apiCall === "function") {
    return client.apiCall(method, args);
  }

  throw new TypeError(`Slack client does not support ${method}`);
}

function isSlackAlreadyReactedError(error: unknown): boolean {
  if (!error || typeof error !== "object") {
    return false;
  }

  const slackError =
    typeof (error as { error?: unknown }).error === "string"
      ? (error as { error: string }).error
      : typeof (error as { data?: { error?: unknown } }).data?.error === "string"
        ? (error as { data: { error: string } }).data.error
        : "";

  return slackError === "already_reacted";
}
