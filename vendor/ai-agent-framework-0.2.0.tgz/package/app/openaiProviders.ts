import { ChatOpenAI } from "@langchain/openai";
import type { AIMessage, BaseMessage } from "@langchain/core/messages";
import type { DynamicStructuredTool } from "@langchain/core/tools";
import type {
  LLMGenerateOptions,
  LLMGenerateResult,
  LLMProvider,
  LLMStreamOptions,
  ToolCall
} from "./providerInterface.js";
import { isDebugLoggingEnabled, logInfo } from "../app/logSink.js";

export class OpenAIProvider implements LLMProvider {
  private apiKey: string;

  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }

  async generate(options: LLMGenerateOptions): Promise<LLMGenerateResult> {
    debugLog("LLM generate request", {
      provider: "openai",
      model: options.model,
      temperature: options.temperature ?? 0.2,
      maxTokens: options.maxTokens ?? null,
      tools: (options.tools ?? []).map((tool) => tool.name),
      messages: serializeMessages(options.messages)
    });

    const llm = new ChatOpenAI({
      openAIApiKey: this.apiKey,
      model: options.model,
      temperature: options.temperature ?? 0.2,
      maxTokens: options.maxTokens,
      streaming: false
    });

    const bound = options.tools && options.tools.length > 0 ? llm.bindTools(options.tools) : llm;
    const message = (await bound.invoke(options.messages)) as AIMessage;
    const toolCalls = extractToolCalls(message);

    debugLog("LLM generate response", {
      provider: "openai",
      model: options.model,
      content: serializeContent(message.content),
      toolCalls
    });

    return { message, toolCalls };
  }

  async *stream(options: LLMStreamOptions): AsyncGenerator<string> {
    debugLog("LLM stream request", {
      provider: "openai",
      model: options.model,
      temperature: options.temperature ?? 0.2,
      maxTokens: options.maxTokens ?? null,
      tools: (options.tools ?? []).map((tool) => tool.name),
      messages: serializeMessages(options.messages)
    });

    const llm = new ChatOpenAI({
      openAIApiKey: this.apiKey,
      model: options.model,
      temperature: options.temperature ?? 0.2,
      maxTokens: options.maxTokens,
      streaming: true
    });

    const bound = options.tools && options.tools.length > 0 ? llm.bindTools(options.tools) : llm;
    const stream = await bound.stream(options.messages);
    let accumulated = "";

    for await (const chunk of stream) {
      const text = typeof chunk.content === "string" ? chunk.content : "";
      if (text) {
        accumulated += text;
        yield text;
      }
    }

    debugLog("LLM stream response", {
      provider: "openai",
      model: options.model,
      content: accumulated
    });
  }
}

function extractToolCalls(message: AIMessage): ToolCall[] {
  const raw = (message.tool_calls ?? message.additional_kwargs?.tool_calls ?? []) as Array<any>;
  if (!Array.isArray(raw)) {
    return [];
  }

  return raw
    .map((call, index) => {
      const name = call.name ?? call.function?.name;
      if (!name) {
        return null;
      }

      const argsRaw = call.args ?? call.function?.arguments ?? "{}";
      let args: Record<string, unknown> = {};
      if (typeof argsRaw === "string") {
        try {
          args = JSON.parse(argsRaw);
        } catch {
          args = {};
        }
      } else if (typeof argsRaw === "object" && argsRaw !== null) {
        args = argsRaw as Record<string, unknown>;
      }

      return {
        id: call.id ?? `call_${index}`,
        name,
        args
      } satisfies ToolCall;
    })
    .filter((call): call is ToolCall => call !== null);
}

function serializeMessages(messages: BaseMessage[]): Array<Record<string, unknown>> {
  return messages.map((message) => ({
    role: getMessageRole(message),
    content: serializeContent((message as any).content),
    name: (message as any).name ?? null,
    tool_call_id: (message as any).tool_call_id ?? null,
    additional_kwargs: (message as any).additional_kwargs ?? {}
  }));
}

function getMessageRole(message: BaseMessage): string {
  const asAny = message as any;
  if (typeof asAny.getType === "function") {
    return asAny.getType();
  }
  if (typeof asAny._getType === "function") {
    return asAny._getType();
  }
  return asAny.constructor?.name ?? "unknown";
}

function serializeContent(content: unknown): unknown {
  if (typeof content === "string") {
    return content;
  }

  return content ?? null;
}

function debugLog(message: string, data?: unknown): void {
  if (!isDebugLoggingEnabled()) {
    return;
  }

  const timestamp = new Date().toISOString();
  if (typeof data === "undefined") {
    logInfo(`[DEBUG ${timestamp}] ${message}`);
    return;
  }

  try {
    logInfo(`[DEBUG ${timestamp}] ${message}`, JSON.stringify(redactDebugValue(data), null, 2));
  } catch {
    logInfo(`[DEBUG ${timestamp}] ${message}`, String(data));
  }
}

function redactDebugValue(value: unknown, depth = 0): unknown {
  if (depth > 8 || value === null || typeof value !== "object") {
    return value;
  }

  if (Array.isArray(value)) {
    return value.map((item) => redactDebugValue(item, depth + 1));
  }

  const source = value as Record<string, unknown>;
  const redacted: Record<string, unknown> = {};
  for (const [key, nestedValue] of Object.entries(source)) {
    const lowered = key.toLowerCase();
    if (
      lowered === "authorization" ||
      lowered === "token" ||
      lowered.endsWith("_token") ||
      lowered === "api_key" ||
      lowered === "apikey" ||
      lowered === "client_secret"
    ) {
      redacted[key] = "REDACTED";
      continue;
    }

    redacted[key] = redactDebugValue(nestedValue, depth + 1);
  }

  return redacted;
}