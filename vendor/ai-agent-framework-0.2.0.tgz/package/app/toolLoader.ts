import { existsSync, readdirSync } from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";
import * as z from "zod/v4";
import { loadMcpProxyToolDefinitions } from "./mcpProxyTools.js";
import { getRuntimeConfig } from "./runtimeConfig.js";
import type {
  ExternalPromptProvider,
  ExternalToolDefinition,
  ExternalToolModule,
  ExternalToolModuleFactory,
  LoadedPromptProvider,
  LoadedToolDefinition
} from "../types/tool.js";

const SUPPORTED_TOOL_EXTENSIONS = new Set([".js", ".mjs", ".cjs", ".ts", ".mts", ".cts"]);
const IGNORED_DIRECTORY_NAMES = new Set(["node_modules", ".git", "dist", "coverage"]);

interface ToolModuleCache {
  signature: string;
  modules: string[];
  tools: LoadedToolDefinition[];
  prompts: LoadedPromptProvider[];
}

let toolModuleCache: ToolModuleCache | null = null;

export async function ensureToolModulesLoaded(
  toolsDir = getRuntimeConfig().toolsDir
): Promise<ToolModuleCache> {
  const resolvedToolsDir = path.resolve(toolsDir);
  const { mcpProxyServers } = getRuntimeConfig();
  const signature = `${resolvedToolsDir}\0${JSON.stringify(mcpProxyServers)}`;

  if (toolModuleCache && toolModuleCache.signature === signature) {
    return toolModuleCache;
  }

  const files = collectToolModuleFiles(resolvedToolsDir);
  const toolNames = new Set<string>();
  const modules: string[] = [];
  const tools: LoadedToolDefinition[] = [];
  const prompts: LoadedPromptProvider[] = [];

  for (const filePath of files) {
    const moduleDefinition = await loadToolModule(filePath);
    modules.push(moduleDefinition.name);

    for (const toolDefinition of moduleDefinition.tools ?? []) {
      const normalized = normalizeToolDefinition(toolDefinition, moduleDefinition.name, filePath);
      if (toolNames.has(normalized.name)) {
        throw new Error(`Duplicate tool name detected: ${normalized.name}`);
      }

      toolNames.add(normalized.name);
      tools.push(normalized);
    }

    if (moduleDefinition.prompts) {
      prompts.push(normalizePromptProvider(moduleDefinition.prompts, moduleDefinition.name, filePath));
    }
  }

  const proxyTools = await loadMcpProxyToolDefinitions(mcpProxyServers);
  for (const proxyTool of proxyTools) {
    if (toolNames.has(proxyTool.name)) {
      throw new Error(
        `Duplicate tool name detected: ${proxyTool.name} (conflicts with a host tool or another MCP proxy)`
      );
    }
    toolNames.add(proxyTool.name);
    tools.push(proxyTool);
  }

  toolModuleCache = {
    signature,
    modules,
    tools,
    prompts
  };

  return toolModuleCache;
}

export function getLoadedToolModuleNames(): string[] {
  return [...(toolModuleCache?.modules ?? [])];
}

export function getAvailableToolNames(): string[] {
  return getLoadedTools().map((tool) => tool.name).sort((left, right) => left.localeCompare(right));
}

export function getLoadedTools(): LoadedToolDefinition[] {
  return [...(toolModuleCache?.tools ?? [])];
}

export function getLoadedPromptProviders(): LoadedPromptProvider[] {
  return [...(toolModuleCache?.prompts ?? [])];
}

export function resetToolModuleCache(): void {
  toolModuleCache = null;
}

function collectToolModuleFiles(directoryPath: string): string[] {
  if (!existsSync(directoryPath)) {
    return [];
  }

  const collected: string[] = [];

  const visit = (currentPath: string) => {
    const entries = readdirSync(currentPath, { withFileTypes: true }).sort((left, right) =>
      left.name.localeCompare(right.name)
    );

    for (const entry of entries) {
      const entryPath = path.join(currentPath, entry.name);

      if (entry.isDirectory()) {
        if (IGNORED_DIRECTORY_NAMES.has(entry.name) || entry.name.startsWith(".")) {
          continue;
        }
        visit(entryPath);
        continue;
      }

      if (!entry.isFile()) {
        continue;
      }

      if (!SUPPORTED_TOOL_EXTENSIONS.has(path.extname(entry.name))) {
        continue;
      }

      collected.push(entryPath);
    }
  };

  visit(directoryPath);
  return collected;
}

async function loadToolModule(filePath: string): Promise<ExternalToolModule> {
  const imported = await import(pathToFileURL(filePath).href);
  const candidateValues = [imported.default, imported, imported.tool].filter(Boolean) as Array<
    ExternalToolModule | ExternalToolModuleFactory | ExternalToolDefinition
  >;

  for (const candidate of candidateValues) {
    const moduleDefinition = await normalizeModuleCandidate(candidate, filePath);
    if (moduleDefinition) {
      return moduleDefinition;
    }
  }

  throw new Error(
    `Invalid tool module export for ${filePath}. Expected a single tool, { tools }, { prompts }, or createTools().`
  );
}

async function normalizeModuleCandidate(
  candidate: ExternalToolModule | ExternalToolModuleFactory | ExternalToolDefinition,
  filePath: string
): Promise<ExternalToolModule | null> {
  if (isToolDefinition(candidate)) {
    return {
      name: candidate.name,
      tools: [candidate]
    };
  }

  if (typeof (candidate as ExternalToolModuleFactory).createTools === "function") {
    const created = await (candidate as ExternalToolModuleFactory).createTools?.();
    if (!created || (!Array.isArray(created.tools) && !isPromptProvider(created.prompts))) {
      throw new Error(`Invalid tool module from ${filePath}: createTools() must return { name, tools } or { name, prompts }.`);
    }

    return {
      name: created.name || path.basename(filePath),
      tools: created.tools ?? [],
      prompts: created.prompts
    };
  }

  if (Array.isArray((candidate as ExternalToolModule).tools) || isPromptProvider((candidate as ExternalToolModule).prompts)) {
    return {
      name: (candidate as ExternalToolModule).name || path.basename(filePath),
      tools: (candidate as ExternalToolModule).tools ?? [],
      prompts: (candidate as ExternalToolModule).prompts
    };
  }

  return null;
}

function normalizePromptProvider(
  prompts: ExternalPromptProvider,
  moduleName: string,
  filePath: string
): LoadedPromptProvider {
  if (!isPromptProvider(prompts)) {
    throw new Error(`Prompt provider from ${moduleName} must provide list(input) and get(input).`);
  }

  return {
    list: prompts.list,
    get: prompts.get,
    moduleName,
    sourcePath: filePath
  };
}

function isPromptProvider(value: unknown): value is ExternalPromptProvider {
  return (
    typeof value === "object" &&
    value !== null &&
    typeof (value as ExternalPromptProvider).list === "function" &&
    typeof (value as ExternalPromptProvider).get === "function"
  );
}

function normalizeToolDefinition(
  tool: ExternalToolDefinition,
  moduleName: string,
  filePath: string
): LoadedToolDefinition {
  const name = normalizeRequiredString(tool.name, `Tool in ${filePath} is missing a valid name.`);
  const description = normalizeRequiredString(
    tool.description,
    `Tool ${name} from ${moduleName} is missing a description.`
  );
  const execute = tool.execute ?? tool.run;

  if (typeof execute !== "function") {
    throw new Error(`Tool ${name} from ${moduleName} must provide execute(input, ctx) or run(input, ctx).`);
  }

  const inputSchema = tool.inputSchema ?? tool.schema ?? z.object({}).passthrough();
  if (typeof (inputSchema as { safeParse?: unknown }).safeParse !== "function") {
    throw new Error(`Tool ${name} from ${moduleName} must provide a Zod-compatible input schema.`);
  }

  if (tool.outputSchema && typeof (tool.outputSchema as { safeParse?: unknown }).safeParse !== "function") {
    throw new Error(`Tool ${name} from ${moduleName} has an invalid outputSchema.`);
  }

  return {
    name,
    title: normalizeOptionalString(tool.title),
    description,
    inputSchema,
    outputSchema: tool.outputSchema,
    execute,
    moduleName,
    sourcePath: filePath
  };
}

function isToolDefinition(value: unknown): value is ExternalToolDefinition {
  return typeof value === "object" && value !== null && "name" in value && "description" in value;
}

function normalizeRequiredString(value: string | undefined, message: string): string {
  const normalized = normalizeOptionalString(value);
  if (!normalized) {
    throw new Error(message);
  }
  return normalized;
}

function normalizeOptionalString(value: string | undefined): string | undefined {
  if (typeof value !== "string") {
    return undefined;
  }

  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : undefined;
}
