const FENCED_CODE_PLACEHOLDER_PREFIX = "SLACKFORMATFENCEDTOKEN";
const INLINE_CODE_PLACEHOLDER_PREFIX = "SLACKFORMATINLINETOKEN";

export function formatForSlackMrkdwn(input: string): string {
  if (!input) {
    return input;
  }

  const normalized = input.replace(/\r\n/g, "\n");
  const fencedExtraction = extractWithPlaceholders(
    normalized,
    /```[\s\S]*?```/g,
    FENCED_CODE_PLACEHOLDER_PREFIX
  );
  const inlineExtraction = extractWithPlaceholders(
    fencedExtraction.text,
    /`[^`\n]+`/g,
    INLINE_CODE_PLACEHOLDER_PREFIX
  );

  let transformed = inlineExtraction.text;
  transformed = convertMarkdownLinks(transformed);
  transformed = convertHeadings(transformed);
  transformed = convertBold(transformed);
  transformed = convertStrike(transformed);
  transformed = normalizeLists(transformed);
  transformed = flattenMarkdownTables(transformed);
  transformed = collapseBlankLines(transformed);

  transformed = restorePlaceholders(
    restorePlaceholders(transformed, inlineExtraction),
    fencedExtraction
  );

  return transformed.trim();
}

function extractWithPlaceholders(
  input: string,
  pattern: RegExp,
  placeholderPrefix: string
): { text: string; replacements: Array<{ token: string; value: string }> } {
  const replacements: Array<{ token: string; value: string }> = [];
  const text = input.replace(pattern, (match) => {
    const token = `${placeholderPrefix}${replacements.length}TOKEN`;
    replacements.push({
      token,
      value: match
    });
    return token;
  });

  return { text, replacements };
}

function restorePlaceholders(
  input: string,
  extraction: { replacements: Array<{ token: string; value: string }> }
): string {
  let output = input;
  for (const replacement of extraction.replacements) {
    output = output.replace(
      new RegExp(escapeRegex(replacement.token), "g"),
      () => replacement.value
    );
  }
  return output;
}

function convertMarkdownLinks(input: string): string {
  return input.replace(
    /(?<!!)\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\)/g,
    (_match, label: string, url: string) => `<${url}|${label.trim()}>`
  );
}

function convertHeadings(input: string): string {
  return input.replace(/^(#{1,6})\s+(.+)$/gm, (_match, _hashes: string, heading: string) => {
    const cleaned = heading.trim();
    return cleaned ? `*${cleaned}*` : "";
  });
}

function convertBold(input: string): string {
  return input
    .replace(/\*\*([^*\n]+)\*\*/g, "*$1*")
    .replace(/__([^_\n]+)__/g, "*$1*");
}

function convertStrike(input: string): string {
  return input.replace(/~~([^~\n]+)~~/g, "~$1~");
}

function normalizeLists(input: string): string {
  return input.replace(/^(\s*)[-*+]\s+/gm, (_match, indent: string) => `${indent}• `);
}

function flattenMarkdownTables(input: string): string {
  const lines = input.split("\n");
  const output: string[] = [];
  let index = 0;

  while (index < lines.length) {
    const line = lines[index] ?? "";
    const next = lines[index + 1] ?? "";

    if (isTableRow(line) && isTableDivider(next)) {
      const headers = splitTableCells(line);
      index += 2;

      while (index < lines.length && isTableRow(lines[index] ?? "")) {
        const row = splitTableCells(lines[index] ?? "");
        const pairs: string[] = [];

        for (let cellIndex = 0; cellIndex < headers.length; cellIndex += 1) {
          const header = headers[cellIndex]?.trim();
          const value = row[cellIndex]?.trim();
          if (!header) {
            continue;
          }

          pairs.push(`${header}: ${value ?? ""}`.trim());
        }

        output.push(pairs.join(" | "));
        index += 1;
      }

      continue;
    }

    output.push(line);
    index += 1;
  }

  return output.join("\n");
}

function isTableRow(line: string): boolean {
  const trimmed = line.trim();
  return trimmed.startsWith("|") && trimmed.endsWith("|") && trimmed.includes("|");
}

function isTableDivider(line: string): boolean {
  const trimmed = line.trim();
  if (!trimmed.startsWith("|") || !trimmed.endsWith("|")) {
    return false;
  }

  return trimmed
    .slice(1, -1)
    .split("|")
    .every((segment) => /^:?-{3,}:?$/.test(segment.trim()));
}

function splitTableCells(row: string): string[] {
  return row
    .trim()
    .slice(1, -1)
    .split("|")
    .map((cell) => cell.trim());
}

function collapseBlankLines(input: string): string {
  return input.replace(/\n{3,}/g, "\n\n");
}

function escapeRegex(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
