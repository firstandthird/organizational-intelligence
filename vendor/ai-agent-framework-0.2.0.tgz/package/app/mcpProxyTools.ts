import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";
import * as z from "zod/v4";
import type { LoadedToolDefinition } from "../types/tool.js";
import type { McpProxyServerConfig } from "./runtimeConfig.js";

const passthroughInput = z.object({}).passthrough();

function formatCallToolResult(result: {
  isError?: boolean;
  content?: Array<{ type?: string; text?: string }>;
  structuredContent?: unknown;
}): string {
  if (!result) {
    return "";
  }
  if (result.isError) {
    return JSON.stringify({ isError: true, content: result.content }, null, 2);
  }
  const blocks = result.content ?? [];
  const textParts: string[] = [];
  for (const block of blocks) {
    if (block?.type === "text" && typeof block.text === "string") {
      textParts.push(block.text);
    }
  }
  const joined = textParts.join("\n").trim();
  if (joined) {
    return joined;
  }
  if (result.structuredContent != null) {
    return JSON.stringify(result.structuredContent, null, 2);
  }
  return JSON.stringify(result, null, 2);
}

function formatProxyError(err: unknown): string {
  if (err instanceof Error) {
    const c = err.cause;
    if (c instanceof Error) {
      return `${err.message} (${c.message})`;
    }
    return err.message;
  }
  return String(err);
}

function isDuplicateMcpToolError(err: unknown): boolean {
  return err instanceof Error && /Duplicate MCP tool name/.test(err.message);
}

/**
 * Connects to each configured MCP proxy (Streamable HTTP), lists tools, and returns
 * {@link LoadedToolDefinition}s whose execute forwards to {@link Client.callTool}.
 * Unreachable or misconfigured servers are skipped with a console warning; host tools still load.
 * Duplicate tool names across servers still fail the whole load (configuration error).
 */
export async function loadMcpProxyToolDefinitions(
  servers: McpProxyServerConfig[]
): Promise<LoadedToolDefinition[]> {
  if (!servers.length) {
    return [];
  }

  const out: LoadedToolDefinition[] = [];
  const seenNames = new Set<string>();

  for (let serverIndex = 0; serverIndex < servers.length; serverIndex++) {
    const server = servers[serverIndex]!;
    let url: URL;
    try {
      url = new URL(server.url);
    } catch {
      console.warn(
        `[MCP proxy] Skipping entry ${serverIndex}: invalid url ${JSON.stringify(server.url)}`
      );
      continue;
    }

    const label = `${url.origin}${url.pathname}`;
    let client: Client | null = null;

    try {
      client = new Client({ name: "slack-ai-bot-mcp-proxy", version: "0.2.0" });
      const transport = new StreamableHTTPClientTransport(url, {
        requestInit: server.authorization
          ? { headers: { Authorization: server.authorization } }
          : undefined
      });
      await client.connect(transport);
      const listed = await client.listTools();
      const remoteTools = listed.tools ?? [];

      for (const t of remoteTools) {
        const toolName = t.name;
        if (seenNames.has(toolName)) {
          await client.close().catch(() => {});
          client = null;
          throw new Error(
            `Duplicate MCP tool name "${toolName}" across proxy servers or duplicate in one server.`
          );
        }
        seenNames.add(toolName);

        const description =
          typeof t.description === "string" && t.description.trim()
            ? t.description.trim()
            : `Proxied MCP tool \`${toolName}\` from ${url.origin}`;

        const clientRef = client;
        out.push({
          name: toolName,
          description,
          inputSchema: passthroughInput,
          execute: async (input) => {
            try {
              const args =
                input && typeof input === "object" && !Array.isArray(input) ? input : {};
              const result = await clientRef.callTool({
                name: toolName,
                arguments: args as Record<string, unknown>
              });
              return formatCallToolResult(result as Parameters<typeof formatCallToolResult>[0]);
            } catch (err) {
              return `MCP proxy tool error (${toolName} @ ${label}): ${formatProxyError(err)}`;
            }
          },
          moduleName: `mcp-proxy:${serverIndex}`,
          sourcePath: `mcp-proxy://${serverIndex}:${encodeURIComponent(label)}`
        });
      }
    } catch (err) {
      if (client) {
        await client.close().catch(() => {});
      }
      if (isDuplicateMcpToolError(err)) {
        throw err;
      }
      console.warn(`[MCP proxy] Skipping ${label}: ${formatProxyError(err)}`);
    }
  }

  return out;
}
