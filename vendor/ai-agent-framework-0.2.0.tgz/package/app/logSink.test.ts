import assert from "node:assert/strict";
import test from "node:test";
import { buildLogTextPreview, buildLogValuePreview, isDebugLoggingEnabled, logToolDebugEvent } from "./logSink.js";

async function withEnv<T>(
  overrides: Record<string, string | undefined>,
  run: () => T | Promise<T>
): Promise<T> {
  const previous = new Map<string, string | undefined>();

  for (const [key, value] of Object.entries(overrides)) {
    previous.set(key, process.env[key]);
    if (typeof value === "string") {
      process.env[key] = value;
    } else {
      delete process.env[key];
    }
  }

  return Promise.resolve(run()).finally(() => {
    for (const [key, value] of previous.entries()) {
      if (typeof value === "string") {
        process.env[key] = value;
      } else {
        delete process.env[key];
      }
    }
  });
}

test("isDebugLoggingEnabled accepts supported truthy values", async () => {
  await withEnv({ DEBUG: "true" }, () => {
    assert.equal(isDebugLoggingEnabled(), true);
  });

  await withEnv({ DEBUG: "1" }, () => {
    assert.equal(isDebugLoggingEnabled(), true);
  });

  await withEnv({ DEBUG: "yes" }, () => {
    assert.equal(isDebugLoggingEnabled(), true);
  });

  await withEnv({ DEBUG: undefined }, () => {
    assert.equal(isDebugLoggingEnabled(), false);
  });
});

test("buildLogTextPreview normalizes whitespace and truncates long text", () => {
  assert.equal(buildLogTextPreview("  hello   world  "), "hello world");
  assert.equal(buildLogTextPreview("abcdef", 4), "abc…");
  assert.equal(buildLogTextPreview("", 10), "");
});

test("buildLogValuePreview redacts sensitive fields and truncates long values", () => {
  const preview = buildLogValuePreview({
    authorization: "secret",
    nested: {
      token: "abc123",
      body: "x".repeat(300)
    }
  }, 80);

  assert.match(preview, /REDACTED/);
  assert.ok(preview.endsWith("…"));
});

test("logToolDebugEvent emits compact redacted previews when DEBUG is enabled", async () => {
  await withEnv({ DEBUG: "on" }, async () => {
    const entries = await withCapturedConsole(async () => {
      logToolDebugEvent("tool_finished", {
        toolName: "http_request",
        callId: "call-123",
        args: {
          authorization: "secret",
          url: "https://example.com"
        },
        result: {
          api_key: "secret",
          body: "x".repeat(400)
        },
        durationMs: 12.4
      });
    });

    assert.equal(entries.length, 1);
    const [entry] = entries;
    assert.ok(entry);
    assert.equal(entry[0], "DEBUG");
    assert.equal(entry[1], "tool_finished");

    const payload = entry[2] as Record<string, string | number>;
    assert.equal(payload.toolName, "http_request");
    assert.equal(payload.callId, "call-123");
    assert.equal(payload.durationMs, 12);
    assert.match(String(payload.argsPreview), /REDACTED/);
    assert.match(String(payload.resultPreview), /REDACTED/);
    assert.ok(String(payload.resultPreview).endsWith("…"));
  });
});

async function withCapturedConsole(run: () => void | Promise<void>): Promise<unknown[][]> {
  const entries: unknown[][] = [];
  const originalLog = console.log;
  console.log = (...args: unknown[]) => {
    entries.push(args);
  };

  try {
    await run();
  } finally {
    console.log = originalLog;
  }

  return entries;
}
