import assert from "node:assert/strict";
import test from "node:test";
import type { SlackMessagingClient } from "./slackMessaging.js";
import { handleSlackMessageEvent } from "./slackMessageHandler.js";

function createSnapshot() {
  return {
    source: "local" as const,
    resolvedAt: Date.now()
  };
}

interface FakeSlackClient extends SlackMessagingClient {
  conversations: {
    replies: (args: Record<string, unknown>) => Promise<{ messages: unknown[] }>;
  };
}

function createFakeSlackClient(): {
  client: FakeSlackClient;
  calls: {
    postMessage: Record<string, unknown>[];
    replies: Record<string, unknown>[];
  };
} {
  const calls = {
    postMessage: [] as Record<string, unknown>[],
    replies: [] as Record<string, unknown>[]
  };

  const client: FakeSlackClient = {
    chat: {
      postMessage: async (args) => {
        calls.postMessage.push(args);
        return { ts: "reply-ts" };
      }
    },
    conversations: {
      replies: async (args) => {
        calls.replies.push(args);
        return { messages: [] };
      }
    }
  };

  return { client, calls };
}

test("adds eyes to the inbound message before running the agent reply", async () => {
  const { client, calls } = createFakeSlackClient();
  const sequence: string[] = [];
  const reactionCalls: Array<Record<string, string>> = [];
  const threadReplyCalls: Array<{ channelId: string; threadTs: string; text: string }> = [];

  await handleSlackMessageEvent(
    {
      channel: "C123",
      thread_ts: "1000.000",
      ts: "1000.111",
      user: "U123",
      text: "Can you take a look?"
    },
    client,
    {
      ensureRuntimeReady: async () => {
        sequence.push("ensure");
      },
      resolveLatestContentSnapshot: async () => {
        sequence.push("snapshot");
        return createSnapshot();
      },
      handlePreviousOutputCommand: async () => {
        sequence.push("previous-output");
        return { handled: false };
      },
      hydrateHistoryWithThreadContinuityState: () => {
        sequence.push("hydrate");
        return [];
      },
      addSlackReaction: async (_client, input) => {
        sequence.push("reaction");
        reactionCalls.push({
          channel: input.channel,
          timestamp: input.timestamp,
          name: input.name
        });
      },
      getRuntimeConfig: (() => ({
        slackMessaging: {
          replyMode: "normal",
          reactionsEnabled: true
        }
      })) as any,
      runDeepAgentTurn: async () => {
        sequence.push("agent");
        return {
          text: "Working on it",
          snapshot: createSnapshot(),
          loadedSkills: [],
          primarySkill: null,
          activeSkills: [],
          usedSkills: [],
          usedTools: [],
          usedOAuthServices: []
        };
      },
      postThreadReply: async (_client, channelId, threadTs, text) => {
        sequence.push("reply");
        threadReplyCalls.push({ channelId, threadTs, text });
      }
    }
  );

  assert.deepEqual(reactionCalls, [
    {
      channel: "C123",
      timestamp: "1000.111",
      name: "eyes"
    }
  ]);
  assert.deepEqual(threadReplyCalls, [
    {
      channelId: "C123",
      threadTs: "1000.000",
      text: "Working on it"
    }
  ]);
  assert.ok(sequence.indexOf("reaction") < sequence.indexOf("agent"));
  assert.equal(calls.postMessage.length, 0);
});

test("does not add eyes for built-in reply paths", async () => {
  const { client, calls } = createFakeSlackClient();
  let reactionCount = 0;

  await handleSlackMessageEvent(
    {
      channel: "C123",
      ts: "1000.111",
      user: "U123",
      text: "refresh agents"
    },
    client,
    {
      ensureRuntimeReady: async () => {},
      refreshGitHubContentSnapshot: async () => createSnapshot(),
      listAgents: async () => [],
      addSlackReaction: async () => {
        reactionCount += 1;
      }
    }
  );

  assert.equal(reactionCount, 0);
  assert.equal(calls.postMessage.length, 1);
});

test("skips eyes when reactions are disabled", async () => {
  const { client } = createFakeSlackClient();
  let reactionCount = 0;
  let replyCount = 0;

  await handleSlackMessageEvent(
    {
      channel: "C123",
      ts: "1000.111",
      user: "U123",
      text: "Please help"
    },
    client,
    {
      ensureRuntimeReady: async () => {},
      resolveLatestContentSnapshot: async () => createSnapshot(),
      handlePreviousOutputCommand: async () => ({ handled: false }),
      hydrateHistoryWithThreadContinuityState: () => [],
      addSlackReaction: async () => {
        reactionCount += 1;
      },
      getRuntimeConfig: (() => ({
        slackMessaging: {
          replyMode: "normal",
          reactionsEnabled: false
        }
      })) as any,
      runDeepAgentTurn: async () => ({
        text: "Answer",
        snapshot: createSnapshot(),
        loadedSkills: [],
        primarySkill: null,
        activeSkills: [],
        usedSkills: [],
        usedTools: [],
        usedOAuthServices: []
      }),
      postThreadReply: async () => {
        replyCount += 1;
      }
    }
  );

  assert.equal(reactionCount, 0);
  assert.equal(replyCount, 1);
});

test("continues replying when the eyes reaction fails", async () => {
  const { client } = createFakeSlackClient();
  let replyCount = 0;
  let agentCount = 0;

  await handleSlackMessageEvent(
    {
      channel: "C123",
      ts: "1000.111",
      user: "U123",
      text: "Please help"
    },
    client,
    {
      ensureRuntimeReady: async () => {},
      resolveLatestContentSnapshot: async () => createSnapshot(),
      handlePreviousOutputCommand: async () => ({ handled: false }),
      hydrateHistoryWithThreadContinuityState: () => [],
      addSlackReaction: async () => {
        throw new Error("reaction failed");
      },
      getRuntimeConfig: (() => ({
        slackMessaging: {
          replyMode: "normal",
          reactionsEnabled: true
        }
      })) as any,
      runDeepAgentTurn: async () => {
        agentCount += 1;
        return {
          text: "Answer",
          snapshot: createSnapshot(),
          loadedSkills: [],
          primarySkill: null,
          activeSkills: [],
          usedSkills: [],
          usedTools: [],
          usedOAuthServices: []
        };
      },
      postThreadReply: async () => {
        replyCount += 1;
      }
    }
  );

  assert.equal(agentCount, 1);
  assert.equal(replyCount, 1);
});

test("posts a confirmation prompt instead of executing destructive work on the first request", async () => {
  const { client } = createFakeSlackClient();
  const pendingWrites: Array<Record<string, unknown>> = [];
  const replies: Array<{ text: string }> = [];

  await handleSlackMessageEvent(
    {
      channel: "C123",
      thread_ts: "1000.000",
      ts: "1000.111",
      user: "U123",
      text: "Create the Google Doc"
    },
    client,
    {
      ensureRuntimeReady: async () => {},
      resolveLatestContentSnapshot: async () => createSnapshot(),
      handlePreviousOutputCommand: async () => ({ handled: false }),
      hydrateHistoryWithThreadContinuityState: () => [],
      getPendingSlackConfirmation: () => null,
      interpretSlackConfirmationReply: () => null,
      recordPendingSlackConfirmation: (input) => {
        pendingWrites.push(input);
      },
      clearPendingSlackConfirmation: () => {},
      getRuntimeConfig: (() => ({
        slackMessaging: {
          replyMode: "normal",
          reactionsEnabled: false
        }
      })) as any,
      runDeepAgentTurn: async (input) => {
        const approved = await input.toolContext.requestConfirmation?.(
          "Confirm destructive action for tool google_docs_create?"
        );
        assert.equal(approved, false);
        return {
          text: "Destructive action was not confirmed.",
          snapshot: createSnapshot(),
          loadedSkills: [],
          primarySkill: "google-docs",
          activeSkills: ["google-docs"],
          usedSkills: ["google-docs"],
          usedTools: ["google_docs_create"],
          usedOAuthServices: ["google-docs"]
        };
      },
      recordThreadContinuityState: () => {},
      postThreadReply: async (_client, _channelId, _threadTs, text) => {
        replies.push({ text });
      }
    }
  );

  assert.equal(pendingWrites.length, 1);
  assert.equal(pendingWrites[0]?.prompt, "Confirm destructive action for tool google_docs_create?");
  assert.equal(replies.length, 1);
  assert.match(replies[0]?.text ?? "", /Reply `yes` to continue or `no` to cancel\./);
});

test("approves destructive work when the user replies yes to a pending confirmation", async () => {
  const { client } = createFakeSlackClient();
  let cleared = 0;
  let approvalSeen: boolean | null = null;

  await handleSlackMessageEvent(
    {
      channel: "C123",
      thread_ts: "1000.000",
      ts: "1000.222",
      user: "U123",
      text: "yes"
    },
    client,
    {
      ensureRuntimeReady: async () => {},
      resolveLatestContentSnapshot: async () => createSnapshot(),
      handlePreviousOutputCommand: async () => ({ handled: false }),
      hydrateHistoryWithThreadContinuityState: () => [],
      getPendingSlackConfirmation: () => ({
        prompt: "Confirm destructive action for tool google_docs_create?",
        requestedAt: Date.now(),
        assistantTurn: null
      }),
      interpretSlackConfirmationReply: () => "approved",
      clearPendingSlackConfirmation: () => {
        cleared += 1;
      },
      recordPendingSlackConfirmation: () => {},
      getRuntimeConfig: (() => ({
        slackMessaging: {
          replyMode: "normal",
          reactionsEnabled: false
        }
      })) as any,
      runDeepAgentTurn: async (input) => {
        approvalSeen =
          (await input.toolContext.requestConfirmation?.(
            "Confirm destructive action for tool google_docs_create?"
          )) ?? null;
        return {
          text: "Created the doc.",
          snapshot: createSnapshot(),
          loadedSkills: [],
          primarySkill: "google-docs",
          activeSkills: ["google-docs"],
          usedSkills: ["google-docs"],
          usedTools: ["google_docs_create"],
          usedOAuthServices: ["google-docs"]
        };
      },
      recordThreadContinuityState: () => {},
      postThreadReply: async () => {}
    }
  );

  assert.equal(approvalSeen, true);
  assert.equal(cleared, 1);
});

test("cancels pending destructive work when the user replies no", async () => {
  const { client, calls } = createFakeSlackClient();
  let agentRan = false;
  let cleared = 0;

  await handleSlackMessageEvent(
    {
      channel: "C123",
      thread_ts: "1000.000",
      ts: "1000.333",
      user: "U123",
      text: "no"
    },
    client,
    {
      ensureRuntimeReady: async () => {},
      resolveLatestContentSnapshot: async () => createSnapshot(),
      handlePreviousOutputCommand: async () => ({ handled: false }),
      hydrateHistoryWithThreadContinuityState: () => [],
      getPendingSlackConfirmation: () => ({
        prompt: "Confirm destructive action for tool google_docs_create?",
        requestedAt: Date.now(),
        assistantTurn: null
      }),
      interpretSlackConfirmationReply: () => "rejected",
      clearPendingSlackConfirmation: () => {
        cleared += 1;
      },
      recordPendingSlackConfirmation: () => {},
      runDeepAgentTurn: async () => {
        agentRan = true;
        return {
          text: "should not run",
          snapshot: createSnapshot(),
          loadedSkills: [],
          primarySkill: null,
          activeSkills: [],
          usedSkills: [],
          usedTools: [],
          usedOAuthServices: []
        };
      }
    }
  );

  assert.equal(agentRan, false);
  assert.equal(cleared, 1);
  assert.equal(calls.postMessage.length, 1);
  assert.equal(calls.postMessage[0]?.text, "Canceled. No changes were made.");
});

test("does not treat unrelated follow-up text as destructive confirmation approval", async () => {
  const { client } = createFakeSlackClient();
  let approvalSeen: boolean | null = null;

  await handleSlackMessageEvent(
    {
      channel: "C123",
      thread_ts: "1000.000",
      ts: "1000.444",
      user: "U123",
      text: "What title should it use?"
    },
    client,
    {
      ensureRuntimeReady: async () => {},
      resolveLatestContentSnapshot: async () => createSnapshot(),
      handlePreviousOutputCommand: async () => ({ handled: false }),
      hydrateHistoryWithThreadContinuityState: () => [],
      getPendingSlackConfirmation: () => ({
        prompt: "Confirm destructive action for tool google_docs_create?",
        requestedAt: Date.now(),
        assistantTurn: null
      }),
      interpretSlackConfirmationReply: () => null,
      clearPendingSlackConfirmation: () => {},
      recordPendingSlackConfirmation: () => {},
      getRuntimeConfig: (() => ({
        slackMessaging: {
          replyMode: "normal",
          reactionsEnabled: false
        }
      })) as any,
      runDeepAgentTurn: async (input) => {
        approvalSeen =
          (await input.toolContext.requestConfirmation?.(
            "Confirm destructive action for tool google_docs_create?"
          )) ?? null;
        return {
          text: "Still waiting for confirmation.",
          snapshot: createSnapshot(),
          loadedSkills: [],
          primarySkill: "google-docs",
          activeSkills: ["google-docs"],
          usedSkills: ["google-docs"],
          usedTools: ["google_docs_create"],
          usedOAuthServices: ["google-docs"]
        };
      },
      recordThreadContinuityState: () => {},
      postThreadReply: async () => {}
    }
  );

  assert.equal(approvalSeen, false);
});

test("logs the original agent failure and posts a Slack error reply", async () => {
  const { client, calls } = createFakeSlackClient();
  const loggedErrors: unknown[][] = [];

  await assert.doesNotReject(async () => {
    await handleSlackMessageEvent(
      {
        channel: "C123",
        thread_ts: "1000.000",
        ts: "1000.111",
        user: "U123",
        text: "Please help"
      },
      client,
      {
        ensureRuntimeReady: async () => {},
        resolveLatestContentSnapshot: async () => createSnapshot(),
        handlePreviousOutputCommand: async () => ({ handled: false }),
        hydrateHistoryWithThreadContinuityState: () => [],
        getRuntimeConfig: (() => ({
          slackMessaging: {
            replyMode: "normal",
            reactionsEnabled: false
          }
        })) as any,
        runDeepAgentTurn: async () => {
          throw new Error("boom");
        },
        logError: (...args) => {
          loggedErrors.push(args);
        }
      }
    );
  });

  assert.equal(loggedErrors.length, 1);
  assert.equal(loggedErrors[0]?.[0], "Slack Deep Agents turn failed");
  assert.deepEqual(loggedErrors[0]?.[1], {
    channelId: "C123",
    threadTs: "1000.000",
    userId: "U123"
  });
  assert.equal(loggedErrors[0]?.[2] instanceof Error, true);
  assert.match(String((loggedErrors[0]?.[2] as Error | undefined)?.message), /boom/);
  assert.equal(calls.postMessage.length, 1);
  assert.equal(calls.postMessage[0]?.channel, "C123");
  assert.equal(calls.postMessage[0]?.thread_ts, "1000.000");
  assert.equal(calls.postMessage[0]?.text, "Something went wrong: boom");
});
