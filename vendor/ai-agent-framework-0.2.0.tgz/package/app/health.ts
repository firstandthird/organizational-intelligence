export function createHealthPayload(service: string): Record<string, unknown> {
  return {
    ok: true,
    service,
    timestamp: new Date().toISOString()
  };
}
