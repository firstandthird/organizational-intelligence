// dotenv
import "dotenv/config";
import {
  AIMessage,
  HumanMessage,
  SystemMessage,
  ToolMessage,
  type BaseMessage
} from "@langchain/core/messages";
import { DynamicStructuredTool } from "@langchain/core/tools";
import type { ToolMessageFields } from "@langchain/core/messages";
import type { LLMProvider } from "./providerInterface.js";
import { OpenAIProvider } from "./openaiProviders.js";
import { getRuntimeConfig } from "./runtimeConfig.js";
import { ensureToolModulesLoaded } from "./toolLoader.js";
import type { LoadedToolDefinition, ToolExecutionContext, ToolResult } from "../types/tool.js";

const DEFAULT_MODEL = "gpt-5.2";
const DEFAULT_TEMPERATURE = 0.2;
const MAX_TOOL_ROUNDS = 8;

export interface SlackLlmTurnInput {
  text: string;
  channelId: string;
  threadTs: string;
  userId?: string;
  attachmentContext?: string | null;
}

export interface SlackLlmTurnResult {
  text: string;
  model: string;
  toolNames: string[];
  toolCallCount: number;
}

/** Minimal shape returned when resolving tools for an LLM turn. */
interface LoadedToolsSnapshot {
  tools: LoadedToolDefinition[];
}

interface SlackLlmTurnDeps {
  getProvider: typeof getProvider;
  /**
   * Default (`ensureToolModulesLoaded`) loads file-backed tool modules from `getRuntimeConfig().toolsDir`
   * and merges tools from remote MCP servers in `MCP_PROXY_SERVERS` (see `toolLoader.ts`).
   */
  loadTools: () => Promise<LoadedToolsSnapshot>;
}

const defaultDeps: SlackLlmTurnDeps = {
  getProvider,
  loadTools: () => ensureToolModulesLoaded()
};

export function getProvider(model: string): LLMProvider {
  const [prefix] = model.split(":");

  const apiKey = process.env.OPENAI_API_KEY;

  if (prefix === "openai" || !model.includes(":")) {
    if (!apiKey) {
      throw new Error("Missing OPENAI_API_KEY for OpenAI provider.");
    }

    return new OpenAIProvider(apiKey);
  }

  throw new Error(`Unsupported provider: ${prefix}`);
}

export async function runSlackLlmTurn(
  input: SlackLlmTurnInput,
  deps: Partial<SlackLlmTurnDeps> = {}
): Promise<SlackLlmTurnResult> {
  const resolvedDeps = {
    ...defaultDeps,
    ...deps
  };
  const runtime = getRuntimeConfig();
  const prompt = composeUserPrompt(input).trim();

  if (!prompt) {
    return {
      text: "How can I help?",
      model: resolveModelName(),
      toolNames: [],
      toolCallCount: 0
    };
  }

  const loaded = await resolvedDeps.loadTools();
  const model = resolveModelName();
  const provider = resolvedDeps.getProvider(model);
  const toolNames = loaded.tools.map((tool) => tool.name);
  const toolMap = new Map(
    loaded.tools.map((tool) => [tool.name, createLangChainTool(tool, input)] as const)
  );
  const messages: BaseMessage[] = [
    new SystemMessage(buildSystemPrompt(runtime.serverName, runtime.mcpRoute, loaded.tools)),
    new HumanMessage(prompt)
  ];

  let toolCallCount = 0;

  for (let round = 0; round < MAX_TOOL_ROUNDS; round += 1) {
    const llmResult = await provider.generate({
      model: stripProviderPrefix(model),
      messages,
      tools: [...toolMap.values()],
      temperature: DEFAULT_TEMPERATURE
    });

    messages.push(llmResult.message);

    if (llmResult.toolCalls.length === 0) {
      return {
        text: extractAiMessageText(llmResult.message) || "I don't have a response for that yet.",
        model,
        toolNames,
        toolCallCount
      };
    }

    toolCallCount += llmResult.toolCalls.length;

    for (const toolCall of llmResult.toolCalls) {
      const tool = toolMap.get(toolCall.name);
      const toolOutput = tool
        ? await tool.invoke(toolCall.args)
        : `Tool ${toolCall.name} is not available in this runtime.`;

      messages.push(
        new ToolMessage({
          tool_call_id: toolCall.id,
          content: normalizeToolMessageContent(toolOutput),
          status: tool ? "success" : "error"
        } satisfies ToolMessageFields)
      );
    }
  }

  return {
    text: "I couldn't complete that request because it required too many tool calls.",
    model,
    toolNames,
    toolCallCount
  };
}

function composeUserPrompt(input: SlackLlmTurnInput): string {
  const text = input.text.trim();
  const attachmentContext = input.attachmentContext?.trim();

  if (text && attachmentContext) {
    return [text, "", attachmentContext].join("\n");
  }

  return text || attachmentContext || "";
}

function createLangChainTool(
  tool: LoadedToolDefinition,
  input: SlackLlmTurnInput
): DynamicStructuredTool {
  return new DynamicStructuredTool({
    name: tool.name,
    description: tool.description,
    schema: tool.inputSchema,
    func: async (args) => {
      const result = await tool.execute(
        (args ?? {}) as Record<string, unknown>,
        createToolExecutionContext(tool.name, input)
      );

      return serializeToolResult(result);
    }
  });
}

function createToolExecutionContext(
  toolName: string,
  input: SlackLlmTurnInput
): ToolExecutionContext {
  return {
    request: {
      requestId: `${toolName}:${Date.now()}`,
      transport: "slack"
    },
    slack: {
      channelId: input.channelId,
      threadTs: input.threadTs,
      userId: input.userId
    }
  };
}

function buildSystemPrompt(
  serverName: string,
  mcpRoute: string,
  tools: LoadedToolDefinition[]
): string {
  const lines = [
    `You are ${serverName}, a Slack assistant that can call MCP-style tools registered for this runtime (host ./tools modules plus tools merged from MCP_PROXY_SERVERS).`,
    "Use tools when they help answer the user's request accurately.",
    "Answer simply in plain text suitable for Slack.",
    "Do not mention internal implementation details unless the user asks."
  ];

  if (tools.length > 0) {
    lines.push(`Tool catalog for this run (this host's MCP route is ${mcpRoute}):`);
    lines.push(...tools.map((tool) => `- ${tool.name}: ${tool.description}`));
  } else {
    lines.push("No tools are currently available (empty tools directory and no reachable MCP proxy servers).");
  }

  return lines.join("\n");
}

function extractAiMessageText(message: AIMessage): string {
  const { content } = message;

  if (typeof content === "string") {
    return content.trim();
  }

  if (!Array.isArray(content)) {
    return "";
  }

  return content
    .map((part) => {
      if (typeof part === "string") {
        return part;
      }

      if (part && typeof part === "object" && "text" in part && typeof part.text === "string") {
        return part.text;
      }

      return "";
    })
    .join("\n")
    .trim();
}

function normalizeToolMessageContent(value: unknown): string {
  if (typeof value === "string") {
    return value;
  }

  if (value && typeof value === "object" && "content" in value) {
    const content = (value as { content?: unknown }).content;
    if (typeof content === "string") {
      return content;
    }
  }

  return serializeToolResult(value as ToolResult);
}

function serializeToolResult(result: ToolResult): string {
  if (typeof result === "string") {
    return result;
  }

  if (typeof result === "undefined" || result === null) {
    return JSON.stringify({ value: result }, null, 2);
  }

  return JSON.stringify(result, null, 2);
}

function resolveModelName(): string {
  const configured =
    process.env.OPENAI_DEFAULT_MODEL ??
    process.env.OPENAI_MODEL ??
    process.env.LLM_MODEL ??
    DEFAULT_MODEL;
  const normalized = configured.trim();

  return normalized || DEFAULT_MODEL;
}

function stripProviderPrefix(model: string): string {
  if (!model.includes(":")) {
    return model;
  }

  const [prefix, ...rest] = model.split(":");
  if (prefix === "openai") {
    return rest.join(":").trim() || DEFAULT_MODEL;
  }

  return model;
}
