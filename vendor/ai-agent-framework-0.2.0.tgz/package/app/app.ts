import type { NextFunction, Request, Response } from "express";
import express from "express";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { createHealthPayload } from "./health.js";
import { createMcpServer } from "./mcpServer.js";
import { getRuntimeConfig, type RuntimeConfig } from "./runtimeConfig.js";
import { slackHandler } from "./slackHandler.js";

/** Raw POST body bytes; @slack/bolt uses this when `express.json()` has already consumed the stream. */
type RequestWithRawBody = Request & { rawBody?: Buffer };

export function createApp(config: RuntimeConfig = getRuntimeConfig()) {
  const app = express();
  app.use(
    express.json({
      verify: (req, _res, buf) => {
        (req as RequestWithRawBody).rawBody = Buffer.from(buf);
      }
    })
  );

  app.get(config.healthRoute, (_req, res) => {
    res.status(200).json(createHealthPayload(config.serverName));
  });

  app.all(config.slackRoute, async (req, res) => {
    await slackHandler(req, res);
  });

  const authMiddleware = createBearerAuthMiddleware(config.authBearerToken);
  app.all(config.mcpRoute, authMiddleware, async (req, res) => {
    if (!["GET", "POST", "DELETE"].includes(req.method)) {
      res.status(405).json({
        jsonrpc: "2.0",
        error: {
          code: -32000,
          message: "Method not allowed."
        },
        id: null
      });
      return;
    }

    const server = await createMcpServer();
    const transport = new StreamableHTTPServerTransport({
      sessionIdGenerator: undefined,
      enableJsonResponse: true
    });
    const cleanup = once(async () => {
      await Promise.allSettled([transport.close(), server.close()]);
    });

    try {
      await server.connect(transport);
      await transport.handleRequest(req, res, req.body);
    } catch (error) {
      if (!res.headersSent) {
        res.status(500).json({
          jsonrpc: "2.0",
          error: {
            code: -32603,
            message: error instanceof Error ? error.message : "Internal server error"
          },
          id: null
        });
      }
    } finally {
      await cleanup();
    }
  });

  return app;
}

function createBearerAuthMiddleware(expectedToken: string | undefined) {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (!expectedToken) {
      next();
      return;
    }

    const authorization = req.headers.authorization;
    const token = parseBearerToken(authorization);
    if (!token || token !== expectedToken) {
      res.status(401).json({
        error: "Unauthorized"
      });
      return;
    }

    next();
  };
}

function parseBearerToken(headerValue: string | undefined): string | undefined {
  if (!headerValue) {
    return undefined;
  }

  const match = headerValue.match(/^Bearer\s+(.+)$/i);
  return match?.[1]?.trim();
}

function once<T>(fn: () => Promise<T>): () => Promise<T | undefined> {
  let called = false;
  return async () => {
    if (called) {
      return undefined;
    }

    called = true;
    return fn();
  };
}
