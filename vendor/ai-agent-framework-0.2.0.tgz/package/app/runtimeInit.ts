import { ensureMemoryTable } from "./memory.js";
import { ensureToolModulesLoaded } from "../tools/index.js";

let runtimeReady = false;

export async function ensureRuntimeReady(): Promise<void> {
  if (runtimeReady) {
    return;
  }

  await ensureMemoryTable();
  await ensureToolModulesLoaded();
  runtimeReady = true;
}
