# AI Agent Framework (slack-ai-bot)

Installable **MCP + Slack** runtime for a **host** repository. The host runs `ai-agent-framework`, which:

- Serves **Streamable HTTP MCP** and **Slack Events** over Express (routes configurable).
- Loads **tools** from the host `./tools` directory (modules exporting tools or `createTools()`).
- **Proxies** additional MCP servers listed in **`MCP_PROXY_SERVERS`** (optional; unreachable servers are skipped with a warning so the process still starts).
- For Slack **app mentions**, runs the **OpenAI** tool loop and posts replies in the thread.

Published npm name: **`ai-agent-framework`**. Requires **Node ≥ 20**.

---

## Host project layout

| Path | Purpose |
|------|---------|
| `./tools/` | Tool modules (`.js`, `.mjs`, `.cjs`, `.ts`, …). Subdirs allowed; `node_modules`, `.git`, `dist` ignored. |
| `./.env` | Primary env file (optional). |
| `./.local.env` | Overrides merged after `.env` (optional). |

**Project root** defaults to **`process.cwd()`** (the directory from which you start the CLI), unless you pass **`--project-root`** or set **`PROJECT_ROOT`**.

**Note:** The runtime merges **`.env`** and **`.local.env`** only—not **`.env.local`**. Use **`.local.env`** for local overrides.

---

## Install in a host repo

```bash
npm install ai-agent-framework
```

Or link a local checkout:

```bash
cd /path/to/slack-ai-bot && npm link
cd /path/to/host && npm link ai-agent-framework
```

After editing the library, run **`npm run build`** in **slack-ai-bot** (the CLI loads **`dist/`**).

To refresh vendored tarballs in sibling repos (**`blue`**, **`organizational-intelligence`**):

```bash
cd /path/to/slack-ai-bot && npm run pack:vendor
```

---

## Run locally

From the **host** directory (so `./tools` and `./.env` resolve correctly):

```bash
# one-off check (loads tools + MCP proxies, then exits)
npx ai-agent-framework --validate

# dev server (default host 127.0.0.1, port 8080 unless overridden)
npx ai-agent-framework --port 8080
```

**CLI flags**

| Flag | Env fallback | Description |
|------|----------------|-------------|
| `--host` | `MCP_HOST` | Bind address (default `127.0.0.1`). |
| `--port`, `-p` | `MCP_PORT` or `PORT` | Listen port (default `8080`). |
| `--project-root` | `PROJECT_ROOT` | Root for `tools/`, `.env`, `package.json` metadata. |
| `--tools-dir` | `TOOLS_DIR` | Tools directory relative to project root or absolute (default `tools`). |
| `--validate`, `--check` | — | Load tools and exit. |

**Library dev** (this repo):

```bash
npm install
npm run dev              # tsx cli.ts
npm run build && npm start
npm test
```

---

## Environment variables

Values are read from **`process.env`**, merged with **`<projectRoot>/.env`** then **`<projectRoot>/.local.env`**: among the two files, **`.local.env` wins** on duplicate keys; then **`process.env` overrides** both for any key present in the environment. See **`mergeEnvFiles`** in `app/runtimeConfig.ts`. The LLM stack also loads **`dotenv/config`** when `app/llm.ts` loads.

### Server & HTTP

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `PROJECT_ROOT` | No | `process.cwd()` | Host root. |
| `MCP_HOST` | No | `127.0.0.1` | HTTP bind host. |
| `MCP_PORT`, `PORT` | No | `8080` | HTTP port. |
| `MCP_ROUTE` | No | `/mcp` | Streamable MCP HTTP path. |
| `HEALTH_ROUTE` | No | `/healthz` | Health JSON path. |
| `SLACK_ROUTE` | No | `/api/slack` | Slack Events URL path. |
| `MCP_AUTH_BEARER_TOKEN` | No | — | If set, MCP **`tools/list`** and **`tools/call`** require `Authorization: Bearer <token>`. |
| `MCP_SERVER_NAME` | No | host `package.json` name or `ai-agent-framework` | Server display name. |
| `MCP_SERVER_VERSION` | No | host/lib version | Server version string. |
| `TOOLS_DIR` | No | `tools` | Host tools directory. |

### Slack

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `SLACK_SIGNING_SECRET` | For Slack | — | Verifies Slack request signatures. |
| `SLACK_BOT_TOKEN` | For Slack replies | — | `xoxb-…` bot token. Both secret + token enable Slack mode. |
| `SLACK_REPLY_MODE` | No | `normal` | `normal` or `stream`. |
| `SLACK_REACTIONS_ENABLED` | No | `true` | `true`/`false`/`1`/`0`/… |
| `SLACK_ATTACHMENTS_ENABLED` | No | `true` | Whether to ingest thread file attachments for the model. |
| `SLACK_ATTACHMENT_MAX_FILE_BYTES` | No | `2000000` | Per-file byte cap. |
| `SLACK_ATTACHMENT_MAX_CHARS_PER_FILE` | No | `50000` | Text extracted per file cap. |
| `SLACK_ATTACHMENT_MAX_FILES_PER_MESSAGE` | No | `8` | Max files per message. |

### MCP proxy (remote Streamable HTTP tools)

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `MCP_PROXY_SERVERS` | No | (empty) | JSON array of objects: **`url`** (required); optional **`bearerToken`** or **`token`** (sent as `Bearer …`); or **`authorization`** (full header value). Invalid entries or unreachable servers are **skipped** (warning to stderr); duplicate tool names across servers still **fail** load. |

Example:

```env
MCP_PROXY_SERVERS=[{"url":"http://127.0.0.1:3000/mcp","bearerToken":"secret"}]
```

### OpenAI (Slack LLM path)

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `OPENAI_API_KEY` | Yes for Slack replies | — | OpenAI API key. |
| `OPENAI_DEFAULT_MODEL`, `OPENAI_MODEL`, `LLM_MODEL` | No | `gpt-5.2` | Chat model (first non-empty wins). |

### Debugging

| Variable | Description |
|----------|-------------|
| `DEBUG` | When truthy (`1`, `true`, `yes`, `on`), enables verbose tool/debug behavior where implemented (`app/logSink.ts`). |

### Optional (examples / agents)

`.env.example` lists additional keys used by **example** tools or docs (e.g. `UNSPLASH_ACCESS_KEY`, `GITHUB_REPO`, …). They are **not** required by the core framework unless your host tools read them.

---

## Slack app setup (summary)

1. Create a Slack app with **Event Subscriptions** → request URL **`https://<your-host><SLACK_ROUTE>`** (same path as this server).
2. Subscribe to **`app_mention`** (and any other events you handle).
3. Install the app to the workspace; set **`SLACK_BOT_TOKEN`** and **`SLACK_SIGNING_SECRET`** in the host `.env`.
4. Invite the bot to channels where it should respond.

---

## Deploy (Google Cloud Run)

Deployment is driven from the **host** repository via the vendored script:

```bash
cd /path/to/host
node ./node_modules/ai-agent-framework/scripts/deploy.js
# or if host defines it:
npm run deploy
```

**Prerequisites**

- **Google Cloud SDK** (`gcloud`) authenticated.
- **Docker** (for image build, unless using a prebuilt image).
- Host **`package.json`** must list **`ai-agent-framework`** in `dependencies` (version or `file:` tarball).

**Deploy-related environment** (read from `process.env` and host **`.env` / `.local.env`** in the current working directory when the script runs):

| Variable | Description |
|----------|-------------|
| `GCLOUD_PROJECT_ID` / `GOOGLE_CLOUD_PROJECT` | GCP project (script has a baked-in default; override in production). |
| `GCLOUD_SERVICE` | Cloud Run service name (defaults to host `package.json` `name`). |
| `GCLOUD_REGION` | e.g. `us-central1`. |
| `GCLOUD_PLATFORM` | e.g. `managed`. |
| `GCLOUD_ALLOW_UNAUTHENTICATED` | `true`/`false` for public HTTP. |
| `GCLOUD_IMAGE` | Optional full image reference to deploy without building. |
| `GCLOUD_IMAGE_REPO`, `GCLOUD_IMAGE_TAG` | Artifact Registry image repo/tag when building. |
| `DEPLOY_DRY_RUN` | `true` to print `gcloud` commands without running. |
| `MCP_HOST`, `MCP_ROUTE`, `HEALTH_ROUTE`, `SLACK_ROUTE` | Baked into the deployed service env. |
| `MCP_AUTH_BEARER_TOKEN` | Optional MCP auth for the deployed service. |
| `MCP_SERVER_NAME` | Display name in Cloud Run env. |
| `SLACK_SIGNING_SECRET`, `SLACK_BOT_TOKEN` | Slack secrets for the deployed revision. |

The script stages a copy of the host, generates a **Dockerfile** and **cloudbuild.yaml**, and runs **`gcloud`** builds/submits. See **`scripts/deploy.js`** for exact behavior and filters (certain files are excluded from the stage).

---

## Programmatic use

Import from **`ai-agent-framework`** (or this repo’s **`dist/index.js`** after build):

- **`configureRuntime(overrides?, env?)`**, **`getRuntimeConfig()`** — routes, Slack, MCP proxy list, etc.
- **`ensureToolModulesLoaded()`** — loads host tools + proxy MCP tools.
- **`createApp`**, **`slackHandler`**, **`createMcpServer`**, etc.
