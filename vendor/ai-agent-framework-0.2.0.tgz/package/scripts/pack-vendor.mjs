import { execSync } from "node:child_process";
import { copyFileSync, mkdirSync, unlinkSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

const vendorTargets = [
  path.resolve(repoRoot, "..", "blue", "vendor"),
  path.resolve(repoRoot, "..", "organizational-intelligence", "vendor")
];

function packTarballPath() {
  const out = execSync("npm pack", {
    cwd: repoRoot,
    encoding: "utf8",
    stdio: ["ignore", "pipe", "inherit"]
  });
  const lines = out
    .trim()
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
  const name = lines.at(-1);
  if (!name?.endsWith(".tgz")) {
    throw new Error(`npm pack did not end with a .tgz line. Output:\n${out}`);
  }
  return path.join(repoRoot, name);
}

function main() {
  const tarball = packTarballPath();
  const base = path.basename(tarball);

  for (const dir of vendorTargets) {
    mkdirSync(dir, { recursive: true });
    const dest = path.join(dir, base);
    copyFileSync(tarball, dest);
    console.log(`Copied ${base} → ${dest}`);
  }

  unlinkSync(tarball);
  console.log(`Removed ${base} from repo root (keeps it out of the next npm pack).`);
}

main();
