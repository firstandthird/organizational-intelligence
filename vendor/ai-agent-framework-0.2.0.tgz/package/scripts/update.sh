npm pack
cp ai-agent-framework-0.2.0.tgz ../blue/vendor/
rm -rf ../blue/node_modules/ai-agent-framework
rm ../blue/package-lock.json