import { spawn } from "node:child_process";
import { cpSync, existsSync, mkdtempSync, readFileSync, rmSync, statSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const DOTENV_VALUES = loadDotEnv();

function env(name, fallback) {
  return process.env[name] ?? DOTENV_VALUES[name] ?? fallback;
}

// exit if no SERVICE_NAME
// if (!process.env.SERVICE_NAME) {
//   console.error("SERVICE_NAME is not set");
//   process.exit(1);
// }
if (!env("SERVICE_NAME", "").trim()) {
  console.error("SERVICE_NAME is not set");
  process.exit(1);
}

const defaults = {
  mcpProxyServers: process.env.MCP_PROXY_SERVERS ?? "",
  openaiApiKey: process.env.OPENAI_API_KEY,
  projectId: "mcps-492915",
  // service: "ai-agent-framework"
  service: process.env.SERVICE_NAME,
  region: "us-central1",
  platform: "managed",
  allowUnauthenticated: true,
  mcpHost: "0.0.0.0",
  mcpRoute: "/mcp",
  healthRoute: "/healthz",
  slackRoute: "/api/slack",
  mcpAuthBearerToken: "token",
};

const SECRET_KEYS = new Set([
  "MCP_AUTH_BEARER_TOKEN",
  "SLACK_SIGNING_SECRET",
  "SLACK_BOT_TOKEN",
  "OPENAI_API_KEY"
]);



export function createDeployablePackageJson(hostPackageJson, packageName = "ai-agent-framework") {
  const dependencyVersion = resolveDependencyVersion(hostPackageJson, packageName);
  if (!dependencyVersion) {
    throw new Error(
      `Host package.json must declare ${packageName} in dependencies before deployment packaging.`
    );
  }

  return {
    ...hostPackageJson,
    private: true,
    type: hostPackageJson.type ?? "module",
    engines: {
      ...(hostPackageJson.engines ?? {}),
      node: hostPackageJson.engines?.node ?? ">=20"
    },
    scripts: {
      ...(hostPackageJson.scripts ?? {}),
      start: `node ./node_modules/${packageName}/dist/cli.js`,
      "mcp:validate": `node ./node_modules/${packageName}/dist/cli.js --validate`
    }
  };
}

export function buildEnvValues(serverName) {
  const values = {
    MCP_HOST: env("MCP_HOST", defaults.mcpHost),
    MCP_ROUTE: env("MCP_ROUTE", defaults.mcpRoute),
    HEALTH_ROUTE: env("HEALTH_ROUTE", defaults.healthRoute),
    SLACK_ROUTE: env("SLACK_ROUTE", defaults.slackRoute),
    MCP_AUTH_BEARER_TOKEN: env("MCP_AUTH_BEARER_TOKEN", defaults.mcpAuthBearerToken),
    MCP_SERVER_NAME: env("MCP_SERVER_NAME", serverName),
    OPENAI_API_KEY: env("OPENAI_API_KEY", defaults.openaiApiKey),
    REPOSITORY_FOLDER: env("REPOSITORY_FOLDER", ""),
    SLACK_SIGNING_SECRET: env("SLACK_SIGNING_SECRET", ""),
    SLACK_BOT_TOKEN: env("SLACK_BOT_TOKEN", ""),
    MCP_PROXY_SERVERS: env("MCP_PROXY_SERVERS", defaults.mcpProxyServers),
  };

  return Object.fromEntries(
    Object.entries(values).filter(([, value]) => String(value).trim().length > 0)
  );
}

function resolveDependencyVersion(hostPackageJson, packageName) {
  return (
    hostPackageJson.dependencies?.[packageName] ??
    hostPackageJson.devDependencies?.[packageName] ??
    hostPackageJson.optionalDependencies?.[packageName]
  );
}

export function createStagingDirectory(hostRoot, generatedPackageJson) {
  const tempRoot = mkdtempSync(path.join(tmpdir(), "ai-agent-framework-deploy-"));
  const stageDir = path.join(tempRoot, "app");
  const lockfileState = {
    hasPackageLock: existsSync(path.join(hostRoot, "package-lock.json")),
    hasPnpmLock: existsSync(path.join(hostRoot, "pnpm-lock.yaml")),
    hasNpmShrinkwrap: existsSync(path.join(hostRoot, "npm-shrinkwrap.json")),
    localDependencyPaths: collectLocalDependencyPaths(generatedPackageJson, hostRoot)
  };

  cpSync(hostRoot, stageDir, {
    recursive: true,
    filter: (source) => shouldCopyToStage(source, hostRoot)
  });
  stageRepositoryFolder(stageDir, hostRoot);

  writeFileSync(
    path.join(stageDir, "package.json"),
    `${JSON.stringify(generatedPackageJson, null, 2)}\n`,
    "utf8"
  );
  writeFileSync(path.join(stageDir, "Dockerfile"), createDockerfile(lockfileState), "utf8");
  writeFileSync(path.join(stageDir, "cloudbuild.yaml"), createCloudBuildYaml(), "utf8");

  return {
    stageDir,
    cleanup: () => rmSync(tempRoot, { recursive: true, force: true })
  };
}

function stageRepositoryFolder(stageDir, hostRoot) {
  const resolvedSource = resolveRepositoryFolderPath(hostRoot);
  if (!resolvedSource) {
    return;
  }

  const destinationName = path.basename(resolvedSource);
  const destinationPath = path.join(stageDir, destinationName);
  rmSync(destinationPath, { recursive: true, force: true });
  cpSync(resolvedSource, destinationPath, { recursive: true });
}

function resolveRepositoryFolderPath(hostRoot) {
  const hostDotEnvValues = loadDotEnv(hostRoot);
  const repositoryFolder = (
    process.env.REPOSITORY_FOLDER ??
    hostDotEnvValues.REPOSITORY_FOLDER ??
    ""
  ).trim();

  if (!repositoryFolder) {
    return "";
  }

  const resolvedSource = path.resolve(hostRoot, repositoryFolder);
  if (!existsSync(resolvedSource) || !statSync(resolvedSource).isDirectory()) {
    throw new Error(`REPOSITORY_FOLDER must reference an existing directory: ${repositoryFolder}`);
  }

  return resolvedSource;
}

function shouldCopyToStage(sourcePath, hostRoot) {
  const resolvedSource = path.resolve(sourcePath);
  const relativePath = path.relative(hostRoot, resolvedSource);

  if (!relativePath) {
    return true;
  }

  const segments = relativePath.split(path.sep);
  const topLevel = segments[0];
  const ignoredTopLevelNames = new Set([
    ".git",
    "node_modules",
    "dist",
    ".next",
    ".vercel",
    "coverage"
  ]);
  const ignoredExactNames = new Set([".env", ".local.env", "Dockerfile", "cloudbuild.yaml"]);

  if (ignoredTopLevelNames.has(topLevel)) {
    return false;
  }

  if (ignoredExactNames.has(relativePath)) {
    return false;
  }

  return true;
}

export function createDockerfile({
  hasPackageLock = false,
  hasPnpmLock = false,
  hasNpmShrinkwrap = false,
  localDependencyPaths = []
} = {}) {
  const lines = [
    "FROM node:20-bookworm-slim",
    "",
    "WORKDIR /app",
    "",
    "RUN corepack enable",
    "",
    "COPY package.json ./"
  ];

  if (hasPackageLock) {
    lines.push("COPY package-lock.json ./");
  }

  if (hasNpmShrinkwrap) {
    lines.push("COPY npm-shrinkwrap.json ./");
  }

  if (hasPnpmLock) {
    lines.push("COPY pnpm-lock.yaml ./");
  }

  for (const dependencyPath of localDependencyPaths) {
    lines.push(createDockerCopyLine(dependencyPath));
  }

  lines.push(
    "RUN if [ -f pnpm-lock.yaml ]; then pnpm install --frozen-lockfile; elif [ -f package-lock.json ] || [ -f npm-shrinkwrap.json ]; then npm ci; else npm install; fi",
    "",
    "COPY . .",
    "RUN if [ -f pnpm-lock.yaml ]; then pnpm run build --if-present; else npm run build --if-present; fi",
    "",
    "ENV NODE_ENV=production",
    "ENV MCP_HOST=0.0.0.0",
    "ENV PORT=8080",
    "",
    "EXPOSE 8080",
    "",
    "CMD [\"sh\", \"-c\", \"if [ -f pnpm-lock.yaml ]; then pnpm start; else npm start; fi\"]",
    ""
  );

  return lines.join("\n");
}

function collectLocalDependencyPaths(hostPackageJson, hostRoot) {
  const dependencySets = [
    hostPackageJson.dependencies,
    hostPackageJson.devDependencies,
    hostPackageJson.optionalDependencies
  ];
  const seen = new Set();
  const localPaths = [];

  for (const dependencySet of dependencySets) {
    if (!dependencySet) {
      continue;
    }

    for (const specifier of Object.values(dependencySet)) {
      if (typeof specifier !== "string" || !specifier.startsWith("file:")) {
        continue;
      }

      const resolvedPath = path.resolve(hostRoot, specifier.slice("file:".length));
      const relativePath = path.relative(hostRoot, resolvedPath);
      const normalizedRelativePath = relativePath.split(path.sep).join("/");

      if (
        !normalizedRelativePath ||
        normalizedRelativePath.startsWith("../") ||
        normalizedRelativePath === ".."
      ) {
        throw new Error(
          `Local file dependency ${specifier} must resolve inside the host project before deployment packaging.`
        );
      }

      if (seen.has(normalizedRelativePath)) {
        continue;
      }

      seen.add(normalizedRelativePath);
      localPaths.push(normalizedRelativePath);
    }
  }

  return localPaths.sort();
}

function createDockerCopyLine(relativePath) {
  const dockerPath = relativePath.split(path.sep).join("/");
  const parentDir = path.posix.dirname(dockerPath);
  const destinationDir = parentDir === "." ? "./" : `./${parentDir}/`;
  return `COPY ["${escapeDockerCopyValue(dockerPath)}", "${escapeDockerCopyValue(destinationDir)}"]`;
}

function escapeDockerCopyValue(value) {
  return value.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
}

function createCloudBuildYaml() {
  return [
    "steps:",
    "  - name: gcr.io/cloud-builders/docker",
    "    args:",
    "      - build",
    "      - -t",
    "      - gcr.io/$PROJECT_ID/${_SERVICE}:$BUILD_ID",
    "      - -t",
    "      - gcr.io/$PROJECT_ID/${_SERVICE}:latest",
    "      - .",
    "",
    "images:",
    "  - gcr.io/$PROJECT_ID/${_SERVICE}:$BUILD_ID",
    "  - gcr.io/$PROJECT_ID/${_SERVICE}:latest",
    "",
    "substitutions:",
    "  _SERVICE: ai-agent-framework",
    ""
  ].join("\n");
}

function writeEnvVarsFile(values) {
  const tempDir = mkdtempSync(path.join(tmpdir(), "ai-agent-framework-env-"));
  const envVarsFilePath = path.join(tempDir, "env-vars.yaml");
  const yamlBody = Object.entries(values)
    .map(([key, value]) => `${key}: ${yamlSingleQuoted(String(value))}`)
    .join("\n");
  writeFileSync(envVarsFilePath, `${yamlBody}\n`, "utf8");

  return {
    envVarsFilePath,
    cleanup: () => rmSync(tempDir, { recursive: true, force: true })
  };
}

function yamlSingleQuoted(value) {
  return `'${value.replace(/'/g, "''")}'`;
}

function buildImageReference(projectId, service) {
  const explicitImage = env("GCLOUD_IMAGE", "");
  if (explicitImage) {
    return explicitImage;
  }

  const defaultRepo = `gcr.io/${projectId}/${service}`;
  const repo = env("GCLOUD_IMAGE_REPO", defaultRepo).replace(/:[^/]+$/, "");
  const tag = env("GCLOUD_IMAGE_TAG", makeImageTag());
  return `${repo}:${tag}`;
}

function makeImageTag() {
  const now = new Date();
  const yyyy = now.getUTCFullYear();
  const mm = String(now.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(now.getUTCDate()).padStart(2, "0");
  const hh = String(now.getUTCHours()).padStart(2, "0");
  const mi = String(now.getUTCMinutes()).padStart(2, "0");
  const ss = String(now.getUTCSeconds()).padStart(2, "0");
  return `${yyyy}${mm}${dd}-${hh}${mi}${ss}`;
}

async function main() {
  const hostRoot = process.cwd();
  const cliArgs = process.argv.slice(2);
  const dryRun =
    cliArgs.includes("--dry-run") || env("DEPLOY_DRY_RUN", "false").toLowerCase() === "true";
  const packageName = readLibraryPackageName();
  const hostPackageJson = readJson(path.join(hostRoot, "package.json"));
  const generatedPackageJson = createDeployablePackageJson(hostPackageJson, packageName);
  const stage = createStagingDirectory(hostRoot, generatedPackageJson);

  const projectId = env("GCLOUD_PROJECT_ID", env("GOOGLE_CLOUD_PROJECT", defaults.projectId));
  const service = env("GCLOUD_SERVICE", hostPackageJson.name ?? defaults.service);
  const region = env("GCLOUD_REGION", defaults.region);
  const platform = env("GCLOUD_PLATFORM", defaults.platform);
  const allowUnauthenticated =
    env("GCLOUD_ALLOW_UNAUTHENTICATED", String(defaults.allowUnauthenticated)).toLowerCase() !==
    "false";
  const image = buildImageReference(projectId, service);
  const envValues = buildEnvValues(hostPackageJson.name ?? service);
  const envVarsFile = writeEnvVarsFile(envValues);

  const buildArgs = ["builds", "submit", "--project", projectId, "--tag", image, stage.stageDir];
  const deployArgs = [
    "run",
    "deploy",
    service,
    "--project",
    projectId,
    "--image",
    image,
    "--region",
    region,
    "--platform",
    platform,
    "--env-vars-file",
    envVarsFile.envVarsFilePath
  ];

  if (allowUnauthenticated) {
    deployArgs.push("--allow-unauthenticated");
  }

  console.log(`Build command:  gcloud ${buildArgs.join(" ")}`);
  console.log(`Deploy command: gcloud ${maskSecretArgs(deployArgs).join(" ")}`);
  console.log(`Staged project: ${stage.stageDir}`);

  if (dryRun) {
    envVarsFile.cleanup();
    console.log(`Dry run preserved staged project at: ${stage.stageDir}`);
    return;
  }

  try {
    await runGcloud(buildArgs);
    await runGcloud(deployArgs);
  } finally {
    envVarsFile.cleanup();
    stage.cleanup();
  }
}

function maskSecretArgs(args) {
  return args.map((arg, index) => {
    if (args[index - 1] !== "--env-vars-file") {
      return arg;
    }

    const values = readEnvFileForDisplay(arg);
    return Object.entries(values)
      .map(([key, value]) => `${key}=${SECRET_KEYS.has(key) ? "****" : value}`)
      .join(",");
  });
}

function readEnvFileForDisplay(filePath) {
  const parsed = {};
  const content = readFileSync(filePath, "utf8");
  for (const rawLine of content.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line) {
      continue;
    }

    const separatorIndex = line.indexOf(":");
    if (separatorIndex < 1) {
      continue;
    }

    const key = line.slice(0, separatorIndex).trim();
    const value = line.slice(separatorIndex + 1).trim().replace(/^'|'$/g, "");
    parsed[key] = value;
  }

  return parsed;
}

function readLibraryPackageName() {
  const moduleDir = path.dirname(fileURLToPath(import.meta.url));
  const candidates = [
    path.resolve(moduleDir, "..", "package.json"),
    path.resolve(moduleDir, "..", "..", "package.json")
  ];

  for (const candidate of candidates) {
    if (!existsSync(candidate)) {
      continue;
    }

    const parsed = readJson(candidate);
    if (typeof parsed.name === "string" && parsed.name.trim()) {
      return parsed.name.trim();
    }
  }

  return "ai-agent-framework";
}

function readJson(filePath) {
  const raw = readFileSync(filePath, "utf8");
  return JSON.parse(raw);
}

async function runGcloud(args) {
  await new Promise((resolvePromise, rejectPromise) => {
    const child =
      process.platform === "win32"
        ? spawn("cmd.exe", ["/d", "/s", "/c", buildWindowsCommand("gcloud", args)], {
            stdio: "inherit"
          })
        : spawn("gcloud", args, { stdio: "inherit" });

    child.on("error", (error) => {
      rejectPromise(new Error(`Failed to start gcloud: ${error.message}`));
    });

    child.on("exit", (code) => {
      if ((code ?? 1) === 0) {
        resolvePromise(undefined);
        return;
      }
      rejectPromise(new Error(`gcloud exited with status ${code ?? 1}`));
    });
  });
}

function buildWindowsCommand(command, args) {
  return [command, ...args.map(quoteForCmd)].join(" ");
}

function quoteForCmd(value) {
  if (!value || /[\s"&<>|^]/.test(value)) {
    return `"${value.replace(/(["\\])/g, "\\$1")}"`;
  }
  return value;
}

function loadDotEnv(rootDir = process.cwd()) {
  const envPaths = [path.resolve(rootDir, ".env"), path.resolve(rootDir, ".local.env")];
  const merged = {};

  for (const envPath of envPaths) {
    if (!existsSync(envPath)) {
      continue;
    }

    const content = readFileSync(envPath, "utf8");
    for (const rawLine of content.split(/\r?\n/)) {
      const line = rawLine.trim();
      if (!line || line.startsWith("#")) {
        continue;
      }

      const separatorIndex = line.indexOf("=");
      if (separatorIndex < 1) {
        continue;
      }

      const key = line.slice(0, separatorIndex).trim();
      let value = line.slice(separatorIndex + 1).trim();
      if (
        (value.startsWith("\"") && value.endsWith("\"")) ||
        (value.startsWith("'") && value.endsWith("'"))
      ) {
        value = value.slice(1, -1);
      }
      merged[key] = value;
    }
  }

  return merged;
}

const isExecutedAsScript = (() => {
  const entry = process.argv[1];
  if (!entry) {
    return false;
  }
  return path.resolve(entry) === path.resolve(fileURLToPath(import.meta.url));
})();

if (isExecutedAsScript) {
  main().catch((error) => {
    console.error(error.message);
    process.exit(1);
  });
}
