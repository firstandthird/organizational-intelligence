# Deploy to Cloud Run

This package is intended to be installed inside a host project that provides a `tools/` folder.

## 1) Prepare the host project

- install `ai-agent-framework`
- add one or more tool modules under `./tools`
- set runtime env vars in `.env` or `.local.env`

Minimum recommended env vars:

```bash
MCP_AUTH_BEARER_TOKEN=replace-with-token
```

Optional Slack env vars:

```bash
SLACK_SIGNING_SECRET=...
SLACK_BOT_TOKEN=...
```

## 2) Set gcloud project and enable APIs

```bash
gcloud config set project YOUR_PROJECT_ID
gcloud services enable run.googleapis.com cloudbuild.googleapis.com
```

## 3) Dry-run the deployment package

From the host project root:

```bash
node ./node_modules/ai-agent-framework/scripts/deploy.js --dry-run
```

This prints the build and deploy commands and creates a temporary staged Cloud Run build context.

## 4) Deploy

```bash
node ./node_modules/ai-agent-framework/scripts/deploy.js
```

Supported deployment env vars:

- `GCLOUD_PROJECT_ID`
- `GCLOUD_SERVICE`
- `GCLOUD_REGION`
- `GCLOUD_PLATFORM`
- `GCLOUD_IMAGE`
- `GCLOUD_IMAGE_REPO`
- `GCLOUD_IMAGE_TAG`
- `GCLOUD_ALLOW_UNAUTHENTICATED`

Runtime env vars passed into Cloud Run:

- `MCP_HOST`
- `MCP_ROUTE`
- `HEALTH_ROUTE`
- `SLACK_ROUTE`
- `MCP_AUTH_BEARER_TOKEN`
- `MCP_SERVER_NAME`
- `SLACK_SIGNING_SECRET`
- `SLACK_BOT_TOKEN`

## 5) Verify

Health:

```bash
curl https://YOUR_CLOUD_RUN_URL/healthz
```

MCP:

```bash
curl -X POST https://YOUR_CLOUD_RUN_URL/mcp \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/list",
    "params": {}
  }'
```

## Notes

- The deploy script follows the same GCR + Cloud Run flow used by the `markdown-to-pdf-server` and `google-sheets-mcp` projects.
- The staged deployment context uses a generated `package.json` with a canonical `start` command that launches `ai-agent-framework`.
