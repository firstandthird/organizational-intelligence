# AI Agent Framework CLI

Runtime and CLI for Slack, inbound webhook, and terminal skill orchestration using markdown-defined skills.

## Core Model
- Skills are markdown files with strict frontmatter.
- Optional `whoami.md` (in the skills content source) is global persona guidance.
- Built-in tools are always available.
- Skill content can come from:
  - Local data folder (`--data <path>`, using `<path>/skills`, optional `<path>/assets`, and optional root `webhooks.json`)
  - GitHub snapshot (`GITHUB_REPO` mode)
- If `--data` is provided, local mode is always used even when `GITHUB_REPO` is set.
- If `GITHUB_REPO` is not set, `--data` is required.

## Quick Start

Install:

```bash
npm install ai-agent-framework
```

Run in local mode:

```bash
npx ai-agent-framework --data ./example --port 3000
```

Validate runtime only:

```bash
npx ai-agent-framework --validate --data ./example
```

Terminal chat mode:

```bash
npx ai-agent-framework --cli --data ./example
```

Seed a message directly to a specific skill:

```bash
npx ai-agent-framework --cli --data ./example --message "summarize this diff" --skill voice --exit-after
```

## Local Data Layout

`--data <path>` expects:

```text
<path>/
  skills/
    <skill-name>/
      SKILL.md
    whoami.md (optional)
  webhooks.json (optional)
  assets/      (optional)
```

Validation rules:
- `<path>` must exist and be a directory.
- `<path>/skills` must exist and be a directory.
- `<path>/webhooks.json` is optional; when present it must be valid JSON matching the webhook schema below.
- `<path>/assets` is optional, but if present it must be a directory.

## GitHub Mode

Set `GITHUB_REPO` (and do not pass `--data`) to load skills from a GitHub repo snapshot.

```bash
export GITHUB_REPO="your-org/your-agent-repo"
export GITHUB_REF="main"                 # optional, default main
export GITHUB_ROOT_PATH="."              # optional, default repo root
export GITHUB_CACHE_TTL_SECONDS="3600"   # optional
export GITHUB_REQUEST_TIMEOUT_MS="5000"  # optional
export GITHUB_TOKEN="..."                # optional for public repos, required for private repos
```

## CLI Flags
- `--data, -d <path>`: local data root (`skills/` + `assets/`), forces local mode.
- `--port, -p <port>`: Slack receiver port (default `3000`).
- `--cli`: interactive terminal mode (Slack listener disabled; `--port` ignored).
- `--message <text>`: seed first CLI message (requires `--cli`).
- `--skill <name>` / `--agent <name>`: force seeded `--message` to one skill (requires `--cli --message`).
- `--exit-after`: exit after seeded message (requires `--cli --message`).
- `--validate`, `--check`: validate runtime then exit.
- `--debug`: set `DEBUG=true` for verbose logging.
- `--log <file>`: append runtime logs to file (parent dir must exist).

## Environment Variables

Required in all modes:
- `OPENAI_API_KEY`

Required for Slack replies / delivery:
- `SLACK_BOT_TOKEN`
- `SLACK_REPLY_MODE` (optional: `normal` or `stream`; defaults to `normal`)
- `SLACK_REACTIONS_ENABLED` (optional: boolean; defaults to `true`; controls the Slack `:eyes:` processing indicator)

Required for Slack event ingestion:
- `SLACK_SIGNING_SECRET`

GitHub mode:
- `GITHUB_REPO`
- `GITHUB_REF` (optional)
- `GITHUB_ROOT_PATH` (optional)
- `GITHUB_CACHE_TTL_SECONDS` (optional)
- `GITHUB_REQUEST_TIMEOUT_MS` (optional)
- `GITHUB_TOKEN` (optional for public repos; required for private repos)

Runtime tuning:
- `DEBUG`
- `THREAD_CONTEXT_MAX_CHARS`
- `OPENAI_DEFAULT_MODEL`
- `ROUTER_MODEL`
- `AGENT_CHAIN_MAX_DEPTH`
- `MEMORY_MAX_CHARS`
- `PERSISTENT_MEMORY_MAX_CHARS`
- `MEMORY_SUMMARY_MODEL`
- `UNSPLASH_ACCESS_KEY` (used by example unsplash agent)

OAuth (when using oauth tools):
- `OAUTH_ENCRYPTION_KEY` (base64-encoded 32-byte key for encrypted OAuth token/state files)
- `OAUTH_BASE_URL` (public base URL used to build `/api/oauth/callback`)
- OAuth client env vars referenced by each agent's `oauth_service` block (for example `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `HARVEST_CLIENT_ID`, `HARVEST_CLIENT_SECRET`; Google vars are used by `google-docs`, `google-sheets`, `google-analytics`, and `google-search-console`)
- `HARVEST_USER_AGENT` (required by `harvest_api`; include app name + contact email)
- `HARVEST_ACCOUNT_ID` (optional fallback account id when OAuth token metadata has no account id)
- `OAUTH_STATE_TTL_SECONDS` (optional; default `600`)
- `GOOGLE_ADS_DEVELOPER_TOKEN` (required by `google-ads` agent for Ads API requests)

OAuth troubleshooting:
- In Google Cloud OAuth client settings, ensure the authorized redirect URI matches exactly:
  - `https://agents-ft.vercel.app/api/oauth/callback` (for this deployment).
- Ensure `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET` in Vercel are from the same OAuth client.
- Ensure `HARVEST_CLIENT_ID` and `HARVEST_CLIENT_SECRET` are from the same Harvest OAuth app.
- Ensure `OAUTH_BASE_URL` exactly matches your public deployment origin (no trailing path beyond domain).
- Redeploy after changing OAuth environment variables so serverless functions pick up updated values.

## Built-in Tools

Built-in tools are always loaded:
- `google_docs_create`
- `google_docs_read`
- `google_docs_update`
- `google_sheets_read`
- `google_sheets_write`
- `harvest_api`
- `http_request`
- `read_asset`
- `openai_image_generate`
- `openai_web_search`
- `list_agents`
- `read_memory_file`
- `write_repo_file`
- `oauth_connect`
- `oauth_list_connections`
- `oauth_status`
- `oauth_disconnect`
- `oauth_access_token`

If a skill references a tool name that is not registered, execution fails fast.

`google_sheets_read` supports `operation: "summarize_sheet"` for sampled spreadsheet context summaries (tabs, headers, and quality signals) in addition to default value reads.

`google_docs_update` supports full document rewrites and heading-based section replacement/appends for targeted edit flows.

Example Google Docs workflow:
- `google-docs: read this doc <doc_url>`
- `copywriter: rewrite this to sound more concise`
- `google-docs: replace the document with the latest rewrite`

## Skill Frontmatter Example

```md
---
name: proposal
description: Drafts and updates proposals
model: openai:gpt-5.2
tools:
  - read_asset
activation_keywords:
  - proposal
  - statement of work
memory: thread
---
```

`activation_keywords` is the preferred name for skill matching hints. `route_keywords` is still accepted as a compatibility alias.

## Project Layout
- `app/`: runtime logic (Slack, routing, loaders, memory, config).
- `tools/internal/`: built-in tools.
- `types/`: shared contracts.
- `cli.ts`: runtime entrypoint.
- `api/`: serverless handlers, including Slack and inbound webhooks.
- `example/`: sample skills/assets/webhooks for local testing.

## Documentation
- [Architecture and functionality overview](/Users/gregallen/code/agents/doc/04-architecture-and-functionality.md)
- [Legacy agent creation reference](/Users/gregallen/code/agents/doc/01-create-an-agent.md)
- [Agent-to-skill migration guide](/Users/gregallen/code/agents/doc/03-migrate-agents-to-skills.md)

## Example Scripts

From this repo:

```bash
npm run run:example
npm run check:example
npm run dev:example
```

## Slack Setup (Summary)
1. Create Slack app and bot user.
2. Add bot scopes for all currently supported Slack features:
   - Core messaging: `app_mentions:read`, `chat:write`, `im:history`, `channels:history`, `groups:history`, `reactions:write`
   - File handling: `files:read`, `files:write`
   - Name-based webhook destination lookup: `channels:read`, `groups:read`, `users:read`
   - Optional: `mpim:history` if you want multi-party DM history support
   - `chat:write` covers both normal replies and streaming replies.
   - `reactions:write` is required for the `:eyes:` processing indicator on inbound messages.
3. Install app; set `SLACK_BOT_TOKEN`.
4. Set `SLACK_SIGNING_SECRET`.
5. Enable Event Subscriptions with request URL:
   - Local CLI: `https://<public-url>/api/slack`
   - Vercel: `https://<domain>/api/slack`
6. Subscribe to bot events: `app_mention`, `message.im`.

## Inbound Webhooks

Inbound webhooks are configured in a root-level `webhooks.json`, not under `assets/`.

Example:

```json
{
  "version": 1,
  "webhooks": [
    {
      "key": "salesforce-lead",
      "agent": "greeting",
      "slack_destination": "#sales",
      "description": "Inbound lead notifications"
    },
    {
      "key": "vercel-deployments",
      "agent": "vercel-webhook",
      "slack_destination": "#deployments",
      "description": "Signed Vercel deployment webhooks",
      "auth": {
        "method": "vercel_signature",
        "secret_env_var": "VERCEL_DEPLOYMENT_WEBHOOK_SECRET"
      }
    }
  ]
}
```

Rules:
- Endpoint: `POST /api/webhooks/:key`
- Content type: `application/json`
- Auth: optional per-webhook via `auth`
- Agent selection: fixed by `webhooks.json`
- Slack destination: fixed by `webhooks.json`
- Caller overrides for `agent` or `channel` are ignored
- Disabled webhooks (`"enabled": false`) are treated as unavailable

`auth` formats:
- Omit `auth` to leave a webhook unauthenticated.
- `{"method":"vercel_signature","secret_env_var":"NAME"}` verifies `x-vercel-signature` using the secret from `process.env.NAME`.
- `{"method":"vercel_signature","secret":"literal-secret"}` verifies the same signature using an inline secret.
- `vercel_signature` requires exactly one of `secret` or `secret_env_var`.
- `secret_env_var` must be an uppercase env var name. Prefer this form for deployed environments.

`slack_destination` formats:
- `#channel-name` or `channel-name`: post to a public/private Slack channel by name
- `@username` or `@display-name`: post as a DM to a matched Slack user
- Raw IDs still work: channel IDs like `C...` / `G...`, DM IDs like `D...`, or user IDs like `U...`

Notes:
- Channel name lookup uses Slack conversation listing, so the app needs `channels:read` and `groups:read`.
- DM name lookup uses Slack user listing, so the app needs `users:read`.
- The Slack `:eyes:` processing indicator uses `reactions:write`.
- DM names are matched exactly, case-insensitively, against Slack username and display name. Ambiguous matches fail fast.

Request handling:
- Returns `202 Accepted` immediately with execution metadata
- Processes the agent run asynchronously
- Posts the final agent output as a new Slack message in the configured channel
- Passes a normalized raw JSON envelope to the agent, including filtered headers, query params, and the parsed body

Example request:

```bash
curl -X POST http://localhost:3000/api/webhooks/hello \
  -H 'content-type: application/json' \
  -d '{"event":"created","id":42}'
```

Signed Vercel example:

```bash
body='{"type":"deployment.created","id":"dep_123"}'
signature=$(printf '%s' "$body" | openssl sha1 -hmac "$VERCEL_DEPLOYMENT_WEBHOOK_SECRET" | awk '{print $2}')

curl -X POST http://localhost:3000/api/webhooks/vercel-deployments \
  -H 'content-type: application/json' \
  -H "x-vercel-signature: $signature" \
  -d "$body"
```

## Vercel Notes
- Serverless handlers are in `api/slack.ts`, `api/webhooks/[key].ts`, `api/health.ts`, and `api/health/github.ts`.
- `vercel.json` enables Fluid Compute so Slack events can ack quickly and both Slack/event work and inbound webhooks can finish with `waitUntil()`.
- For GitHub mode deployments, set `GITHUB_REPO` (+ `GITHUB_TOKEN` for private repos).
- For local data mode in CLI/host environments, run with `--data <path>`.

## Notes
- `process this` in-thread reprocessing disables tools unless explicitly requested.
- `@bot ^` reprocesses the nearest earlier non-bot, non-command user message in the same thread (optional: `@bot ^ <instruction>`).
- Standalone `^` in a thread is ignored; the caret command only works through `@` mention.
- `reroute <agent>` reruns the last routed user turn with the named agent. In Slack it first redacts the superseded bot reply in place, falls back to delete if redaction fails, and aborts if neither cleanup path works.
- Previous-output export also recognizes natural phrases like `can I get this in a markdown file` and `save the last response as markdown`.
- Thread memory summaries are process-local and reset on restart.
- `remember this` persists to `memory/<agent>.md` (or `memory/system.md` for system target).
- Control commands (`process this`, `^`, `remember this`, previous-output export, `reroute <agent>`) are excluded from future thread context.
- In GitHub mode, each persistent memory write creates a commit on the configured ref branch.
- OAuth tokens/states are encrypted at rest in `memory/oauth_tokens.enc.json` and `memory/oauth_states.enc.json`.
- `memory/system.md` is injected with `whoami.md` context for routed and unrouted responses.
- Internal `memory-reader` agent can read stored memory (`memory/<agent>.md` and `memory/system.md`).
- Example: `memory-reader: show memory for voice` or `memory-reader: show system memory`.
- Thread routing uses question-aware continuity:
  - Continue with the last responder only when their previous reply asked a question.
  - Re-route to a different agent when router confidence is high (`>= 0.80`).
  - Explicit invocation (`<agent>: ...` or `system: ...`) always overrides continuity for that turn.
