This directory is reserved for built-in skills that ship with the framework package.

Phase 1 uses `skills/<name>/SKILL.md` as the canonical local skill layout.
